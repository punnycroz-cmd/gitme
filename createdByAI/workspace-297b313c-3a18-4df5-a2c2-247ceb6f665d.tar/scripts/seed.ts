// TinyHub — seed script.
// Imports the original Cloudflare Workers TinyHub project files from /tmp/uploaded/
// into the database via performCommit, plus a small `hello` demo project.
//
// Run: `bun run scripts/seed.ts`

import { promises as fs } from "fs";
import path from "path";
import { performCommit, type CommitResult } from "../src/lib/commit";

const UPLOAD_ROOT = "/tmp/uploaded";

/// Recursively walk a directory and return [{ relPath, bytes }].
async function readAllFiles(root: string): Promise<Array<{ relPath: string; bytes: Uint8Array }>> {
  const out: Array<{ relPath: string; bytes: Uint8Array }> = [];
  async function recurse(dir: string): Promise<void> {
    let entries: import("fs").Dirent[];
    try {
      entries = await fs.readdir(dir, { withFileTypes: true });
    } catch {
      return;
    }
    for (const e of entries) {
      const full = path.join(dir, e.name);
      if (e.isDirectory()) {
        await recurse(full);
      } else if (e.isFile()) {
        const buf = await fs.readFile(full);
        const rel = path.relative(root, full).split(path.sep).join("/");
        out.push({ relPath: rel, bytes: new Uint8Array(buf) });
      }
    }
  }
  await recurse(root);
  out.sort((a, b) => a.relPath.localeCompare(b.relPath));
  return out;
}

async function seedGitme(): Promise<void> {
  console.log(`[seed] reading files from ${UPLOAD_ROOT} ...`);
  const files = await readAllFiles(UPLOAD_ROOT);
  console.log(`[seed] found ${files.length} files`);

  const fileMap = new Map<string, Uint8Array>();
  for (const f of files) {
    fileMap.set(f.relPath, f.bytes);
  }

  console.log(`[seed] committing as project "gitme" ...`);
  const result: CommitResult = await performCommit({
    proj: "gitme",
    message: "Initial import of original TinyHub project",
    files: fileMap,
    mode: "push",
    author: "Andie",
  });

  console.log("[seed] gitme commit result:");
  console.log(`   ok:        ${result.ok}`);
  console.log(`   commit:    ${result.commit.hash}`);
  console.log(`   message:   ${result.commit.message}`);
  console.log(`   author:    ${result.commit.author}`);
  console.log(
    `   stats:     +${result.stats.added} ~${result.stats.modified} -${result.stats.deleted} (unchanged: ${result.stats.unchanged})`
  );
  console.log(`   saved:     ${result.saved.length} files`);
  console.log(`   added:     ${result.added.length} files`);
  console.log(`   modified:  ${result.modified.length} files`);
  console.log(`   deleted:   ${result.deleted.length} files`);
  console.log(`   blocked:   ${result.blocked.length} files`);
  if (result.blocked.length > 0) {
    console.log(`   blocked paths: ${result.blocked.join(", ")}`);
  }
}

async function seedHello(): Promise<void> {
  console.log(`[seed] committing demo project "hello" ...`);
  const encoder = new TextEncoder();
  const fileMap = new Map<string, Uint8Array>([
    ["README.md", encoder.encode("# Hello\n\nA demo project.\n")],
    ["app.js", encoder.encode('console.log("hello world");\n')],
  ]);

  const result = await performCommit({
    proj: "hello",
    message: "Initial commit",
    files: fileMap,
    mode: "push",
    author: "Andie",
  });

  console.log("[seed] hello commit result:");
  console.log(`   ok:        ${result.ok}`);
  console.log(`   commit:    ${result.commit.hash}`);
  console.log(`   message:   ${result.commit.message}`);
  console.log(`   files:     ${result.saved.length} added`);
}

async function main(): Promise<void> {
  console.log("=== TinyHub seed ===");
  try {
    await seedGitme();
  } catch (err) {
    console.error("[seed] gitme failed:", err);
    process.exitCode = 1;
  }
  try {
    await seedHello();
  } catch (err) {
    console.error("[seed] hello failed:", err);
    process.exitCode = 1;
  }
  console.log("=== seed complete ===");
}

main()
  .catch((err) => {
    console.error("[seed] fatal:", err);
    process.exit(1);
  })
  .finally(async () => {
    // Import db dynamically so we can disconnect.
    try {
      const { db } = await import("../src/lib/db");
      await db.$disconnect();
    } catch {
      /* ignore */
    }
  });
