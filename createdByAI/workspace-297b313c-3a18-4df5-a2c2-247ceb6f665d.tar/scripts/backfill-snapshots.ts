// TinyHub — backfill BlobSnapshot rows for existing commits.
//
// For every complete commit, for each CommitFile that is "added" or "modified",
// we need a BlobSnapshot row pointing to the file content AT that commit.
// Since we don't have historical content, we snapshot the CURRENT file content
// for the tip commit only (the most recent commit per project). Older commits
// get their snapshot from the current file state too — this is an approximation
// (the file may have drifted since an older commit), but it's the best we can
// do without time travel. The diff viewer will show a note for non-tip commits
// whose snapshots may have drifted.
//
// For pre-snapshot commits this gives us:
//   - tip commit: exact after-content (correct)
//   - older commits: after-content = current file (may differ from commit time,
//     flagged by isTip:false + the note). before-content for modified files
//     in older commits may be null if the ancestor has no snapshot either.
//
// Run: `bun run scripts/backfill-snapshots.ts`

import { db } from "../src/lib/db";
import { DEFAULT_USER } from "../src/lib/config";
import { getFile, putSnapshot } from "../src/lib/storage";
import { sha256Bytes } from "../src/lib/security";
import { countLines } from "../src/lib/helpers";

async function backfillProject(user: string, proj: string): Promise<void> {
  // Get all complete commits for this project, oldest first (so ancestors
  // get their snapshots before descendants try to read them).
  const commits = await db.commit.findMany({
    where: { user, proj, status: "complete" },
    orderBy: { createdAt: "asc" },
    select: { id: true, hash12: true },
  });

  let created = 0;
  let skipped = 0;

  for (const commit of commits) {
    const fileRows = await db.commitFile.findMany({
      where: { commitId: commit.id },
      select: { path: true, changeType: true },
    });

    for (const cf of fileRows) {
      if (cf.changeType === "deleted") continue; // no after-content to snapshot

      // Check if a snapshot already exists for this (commit, path).
      const existing = await db.blobSnapshot.findUnique({
        where: {
          user_proj_commitId_path: { user, proj, commitId: commit.id, path: cf.path },
        },
        select: { sha256: true },
      });
      if (existing) {
        skipped++;
        continue;
      }

      // Read the CURRENT file content (best approximation for pre-snapshot commits).
      const bytes = await getFile(user, proj, cf.path);
      if (!bytes) {
        // File no longer exists (deleted in a later commit). Skip — the diff
        // endpoint will walk ancestors and find nothing, returning before:null.
        continue;
      }

      const sha = await sha256Bytes(bytes);
      const size = bytes.byteLength;
      const lines = countLines(bytes);

      // Write the content-addressed snapshot blob (deduped).
      await putSnapshot(user, proj, sha, bytes);

      // Write the BlobSnapshot row.
      await db.blobSnapshot.create({
        data: {
          user,
          proj,
          commitId: commit.id,
          path: cf.path,
          sha256: sha,
          size,
          lines,
        },
      });
      created++;
    }
  }

  console.log(`  ${proj}: ${commits.length} commits, ${created} snapshots created, ${skipped} already present`);
}

async function main() {
  console.log("Backfilling BlobSnapshot rows for all projects...");
  const projects = await db.project.findMany({
    where: { user: DEFAULT_USER },
    select: { proj: true },
  });
  for (const p of projects) {
    await backfillProject(DEFAULT_USER, p.proj);
  }
  console.log("Done.");
}

main()
  .catch((err) => {
    console.error("Backfill failed:", err);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
