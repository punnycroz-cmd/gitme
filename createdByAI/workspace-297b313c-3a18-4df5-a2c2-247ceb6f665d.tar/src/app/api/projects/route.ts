// TinyHub — list projects for the default user (with real storage bytes)
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

export async function GET(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  try {
    const projects = await db.project.findMany({
      where: { user: DEFAULT_USER },
      orderBy: { updatedAt: "desc" },
      select: {
        proj: true,
        updatedAt: true,
        filesCount: true,
        commitsCount: true,
        lastCommit: true,
      },
    });

    // Compute real total bytes per project from the FileBlob table (source of truth).
    // Group by proj and sum sizes in one query.
    const projNames = projects.map((p) => p.proj);
    const sizeAgg =
      projNames.length > 0
        ? await db.fileBlob.groupBy({
            by: ["proj"],
            where: { user: DEFAULT_USER, proj: { in: projNames } },
            _sum: { size: true },
          })
        : [];
    const sizeMap = new Map<string, number>(
      sizeAgg.map((r) => [r.proj, r._sum.size ?? 0])
    );

    return Response.json(
      projects.map((p) => ({
        name: p.proj,
        updatedAt: Number(p.updatedAt),
        filesCount: p.filesCount,
        commitsCount: p.commitsCount,
        lastCommit: p.lastCommit,
        totalBytes: sizeMap.get(p.proj) ?? 0,
      }))
    );
  } catch (err) {
    console.error("[projects] list error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}

