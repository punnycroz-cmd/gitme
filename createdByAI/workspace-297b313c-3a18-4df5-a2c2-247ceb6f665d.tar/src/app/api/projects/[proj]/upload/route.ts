// TinyHub — multipart upload commit endpoint
import { NextRequest } from "next/server";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import {
  safeProj,
  safeRelPath,
  isBlocked,
  normalizeUploadPath,
} from "@/lib/security";
import { safeJsonParse } from "@/lib/helpers";
import {
  performCommit,
  CommitError,
  type CommitResult,
} from "@/lib/commit";
import {
  applyRateLimit,
  requireWriteAuth,
  handleOptions,
  apiError,
  json,
} from "@/lib/api";

export const runtime = "nodejs";

type Mode = "push" | "merge" | "replace";

function isValidMode(m: string | null): m is Mode {
  return m === "push" || m === "merge" || m === "replace";
}

/// Read a File into bytes, optionally gzip-decompressing.
async function fileToBytes(
  file: File,
  gzip: boolean,
  maxBytes: number
): Promise<Uint8Array> {
  let stream: ReadableStream<Uint8Array> = file.stream() as ReadableStream<Uint8Array>;
  if (gzip) {
    const ds = new DecompressionStream("gzip");
    stream = stream.pipeThrough(ds as unknown as TransformStream<Uint8Array, Uint8Array>);
  }
  const reader = stream.getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (value) {
        total += value.byteLength;
        if (total > maxBytes) {
          throw new Error(`__TOO_LARGE__:${total}`);
        }
        chunks.push(value);
      }
    }
  } finally {
    try {
      reader.releaseLock();
    } catch {
      /* ignore */
    }
  }
  const out = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.byteLength;
  }
  return out;
}

interface SkippedFile {
  path: string;
  reason: string;
  size?: number;
}

function handleCommitError(err: unknown): Response {
  if (err instanceof CommitError) {
    const msg = err.message;
    if (msg.startsWith("{")) {
      try {
        const body = JSON.parse(msg) as Record<string, unknown>;
        return json(body, err.status);
      } catch {
        /* fall through */
      }
    }
    return apiError(msg, err.status);
  }
  console.error("[commit-engine] error:", err);
  return apiError("Internal server error", 500);
}

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 5);
  if (rl) return rl;

  const auth = requireWriteAuth(req);
  if (auth) return auth;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return apiError("Invalid project name", 400);
  }

  let form: FormData;
  try {
    form = await req.formData();
  } catch {
    return apiError("Invalid multipart form data", 400);
  }

  const modeRaw = (form.get("mode") as string | null) || "push";
  if (!isValidMode(modeRaw)) {
    return apiError("Invalid mode (push|merge|replace)", 400);
  }
  const mode: Mode = modeRaw;

  const message = (form.get("message") as string | null) || "";
  const baseTip = (form.get("baseTip") as string | null) || undefined;
  const incremental = form.get("incremental") === "1";
  // Optional author override (from Settings). Falls back to "Andie".
  const authorRaw = (form.get("author") as string | null) || "";
  const author = authorRaw.trim() ? authorRaw.trim().slice(0, 100) : "Andie";

  // deletes: JSON string array
  let deletes: string[] = [];
  const deletesRaw = form.get("deletes");
  if (typeof deletesRaw === "string" && deletesRaw.trim()) {
    const parsed = safeJsonParse<string[] | null>(deletesRaw, null);
    if (!Array.isArray(parsed)) {
      return apiError("Invalid 'deletes' JSON (expected string array)", 400);
    }
    for (const d of parsed) {
      if (typeof d !== "string") continue;
      const safe = safeRelPath(d);
      if (!safe || isBlocked(safe)) continue;
      deletes.push(safe);
    }
  }

  // encodings: JSON map path -> "gzip"
  const encodingsRaw = form.get("encodings");
  const encodings: Record<string, string> =
    typeof encodingsRaw === "string" && encodingsRaw.trim()
      ? safeJsonParse<Record<string, string>>(encodingsRaw, {})
      : {};

  const files = new Map<string, Uint8Array>();
  const blocked: string[] = [];
  const skipped: SkippedFile[] = [];

  // Iterate all File entries (skip known scalar fields).
  const knownFields = new Set([
    "mode",
    "message",
    "baseTip",
    "incremental",
    "deletes",
    "encodings",
  ]);

  for (const [key, value] of form.entries()) {
    if (knownFields.has(key)) continue;
    if (!(value instanceof File)) continue;

    const normalized = normalizeUploadPath(value.name, proj);
    if (!normalized || isBlocked(normalized)) {
      blocked.push(value.name);
      continue;
    }
    if (files.has(normalized)) {
      // Duplicate — last wins; skip the earlier occurrence silently.
    }

    const encoding = encodings[normalized] || encodings[value.name] || "";
    const isGzip = encoding === "gzip";

    // Early reject on raw upload size.
    if (value.size > LIMITS.MAX_FILE_SIZE * (isGzip ? 4 : 1)) {
      return apiError(
        `File too large: ${normalized} exceeds ${LIMITS.MAX_FILE_SIZE} bytes`,
        413
      );
    }

    let bytes: Uint8Array;
    try {
      bytes = await fileToBytes(value, isGzip, LIMITS.MAX_FILE_SIZE);
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (msg.startsWith("__TOO_LARGE__")) {
        return apiError(
          `File too large: ${normalized} exceeds ${LIMITS.MAX_FILE_SIZE} bytes`,
          413
        );
      }
      skipped.push({ path: normalized, reason: `decode failed: ${msg}`, size: value.size });
      continue;
    }

    files.set(normalized, bytes);
  }

  // Edge: no files and not incremental and not push -> require deletes or files
  if (files.size === 0 && !incremental && mode !== "push" && deletes.length === 0) {
    return apiError("No files uploaded", 400);
  }
  if (incremental && files.size === 0 && deletes.length === 0) {
    return apiError("No files or deletes provided for incremental commit", 400);
  }

  let result: CommitResult;
  try {
    result = await performCommit({
      user: DEFAULT_USER,
      proj,
      message,
      files,
      deletes,
      mode,
      incremental,
      baseTip,
      author,
    });
  } catch (err) {
    return handleCommitError(err);
  }

  // 409 if conflict result (rare — handleCommitError covers CommitError 409)
  const status = result.ok ? 200 : 409;
  return json({ ...result, skipped }, status);
}
