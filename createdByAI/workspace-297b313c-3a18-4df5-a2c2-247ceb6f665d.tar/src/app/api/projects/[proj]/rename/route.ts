// TinyHub — file rename/move endpoint.
// Renames a file by reading its current bytes and committing them at the new path
// while deleting the old path. Works for both text AND binary files (uses raw bytes,
// unlike the JSON commit endpoint). Implemented as a dedicated endpoint because
// `commitProject` (the JSON endpoint) only supports text content.
import { NextRequest } from "next/server";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj, safeRelPath, isBlocked } from "@/lib/security";
import { safeJsonParse } from "@/lib/helpers";
import { getFile } from "@/lib/storage";
import {
  performCommit,
  CommitError,
  type CommitResult,
} from "@/lib/commit";
import {
  applyRateLimit,
  requireWriteAuth,
  handleOptions,
  apiError,
  json,
} from "@/lib/api";

export const runtime = "nodejs";

function handleCommitError(err: unknown): Response {
  if (err instanceof CommitError) {
    const msg = err.message;
    if (msg.startsWith("{")) {
      try {
        const body = JSON.parse(msg) as Record<string, unknown>;
        return json(body, err.status);
      } catch {
        /* fall through */
      }
    }
    return apiError(msg, err.status);
  }
  console.error("[rename] error:", err);
  return apiError("Internal server error", 500);
}

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 5);
  if (rl) return rl;

  const auth = requireWriteAuth(req);
  if (auth) return auth;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return apiError("Invalid project name", 400);
  }

  let raw: string;
  try {
    raw = await req.text();
  } catch {
    return apiError("Invalid request body", 400);
  }
  if (raw.length > 1_000_000) {
    return apiError("Request body too large", 413);
  }

  const body = safeJsonParse<
    | { from?: unknown; to?: unknown; message?: unknown; baseTip?: unknown; author?: unknown }
    | null
  >(raw, null);
  if (!body || typeof body !== "object") {
    return apiError("Invalid JSON body", 400);
  }

  if (typeof body.from !== "string" || typeof body.to !== "string") {
    return apiError("'from' and 'to' must be strings", 400);
  }

  const from = safeRelPath(body.from);
  const to = safeRelPath(body.to);
  if (!from) {
    return apiError(`Invalid source path: ${body.from}`, 400);
  }
  if (!to) {
    return apiError(`Invalid target path: ${body.to}`, 400);
  }
  if (isBlocked(from) || isBlocked(to)) {
    return apiError("Source or target path is blocked", 400);
  }
  if (from === to) {
    return apiError("Source and target paths are identical", 400);
  }

  const message =
    typeof body.message === "string"
      ? body.message.slice(0, LIMITS.MAX_MESSAGE_LEN)
      : "";
  const baseTip =
    typeof body.baseTip === "string" ? body.baseTip : undefined;
  const author =
    typeof body.author === "string" && body.author.trim()
      ? body.author.trim().slice(0, 100)
      : "TinyHub";

  // Read current bytes for the source file (works for binary + text).
  const bytes = await getFile(DEFAULT_USER, proj, from);
  if (!bytes) {
    return apiError(`Source file not found: ${from}`, 404);
  }
  if (bytes.byteLength > LIMITS.MAX_FILE_SIZE) {
    return apiError(
      `File too large: ${from} exceeds ${LIMITS.MAX_FILE_SIZE} bytes`,
      413
    );
  }

  let result: CommitResult;
  try {
    result = await performCommit({
      user: DEFAULT_USER,
      proj,
      message: message || `Rename ${from} → ${to}`,
      files: new Map<string, Uint8Array>([[to, bytes]]),
      deletes: [from],
      mode: "push",
      incremental: true,
      baseTip,
      author,
    });
  } catch (err) {
    return handleCommitError(err);
  }

  return json(result, 200);
}
