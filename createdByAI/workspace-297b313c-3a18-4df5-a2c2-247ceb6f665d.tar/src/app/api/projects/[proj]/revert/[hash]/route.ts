// TinyHub — revert a commit (creates a NEW commit that undoes the changes).
//
// For commit C with parent P:
//   - Files ADDED by C   → delete them (they didn't exist at P)
//   - Files MODIFIED by C → restore to their content at P (ancestor snapshot)
//   - Files DELETED by C  → restore to their content at P (ancestor snapshot)
//
// Uses the BlobSnapshot system to fetch historical content. If a snapshot is
// missing (pre-backfill commit), returns a warning in the response.
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj, safeRelPath, isBlocked } from "@/lib/security";
import { getSnapshotText } from "@/lib/storage";
import { performCommit, CommitError } from "@/lib/commit";
import {
  applyRateLimit,
  requireWriteAuth,
  handleOptions,
  apiError,
  json,
} from "@/lib/api";

export const runtime = "nodejs";

const HASH_RE = /^[a-f0-9]{12}$/;
const MAX_ANCESTOR_WALK = 200;

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string; hash: string }> }
) {
  if (req.method === "OPTIONS") {
    const rl = applyRateLimit(req, 1);
    if (rl) return rl;
    return handleOptions();
  }

  const rl = applyRateLimit(req, 5);
  if (rl) return rl;

  const auth = requireWriteAuth(req);
  if (auth) return auth;

  const { proj: rawProj, hash: rawHash } = await params;
  const proj = safeProj(rawProj);
  if (!proj) return apiError("Invalid project name", 400);

  const hash = (rawHash || "").trim().toLowerCase();
  if (!HASH_RE.test(hash)) {
    return apiError("Invalid commit hash (expected 12 hex chars)", 400);
  }

  let message = "";
  try {
    const body = await req.json();
    if (typeof body?.message === "string") {
      message = body.message.slice(0, LIMITS.MAX_MESSAGE_LEN);
    }
  } catch {
    /* no body or invalid JSON — use default message */
  }

  try {
    const commit = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, hash12: hash, status: "complete" },
      select: { id: true, hash12: true, parentHash12: true, message: true },
    });
    if (!commit) return apiError("Commit not found", 404);

    if (!commit.parentHash12) {
      return apiError(
        "Cannot revert the initial commit (no parent to restore to)",
        400
      );
    }

    const fileRows = await db.commitFile.findMany({
      where: { commitId: commit.id },
      select: { path: true, changeType: true },
    });

    const parent = await db.commit.findFirst({
      where: {
        user: DEFAULT_USER,
        proj,
        hash12: commit.parentHash12,
        status: "complete",
      },
      select: { id: true },
    });
    if (!parent) return apiError("Parent commit not found", 404);

    const filesToRestore = new Map<string, Uint8Array>();
    const pathsToDelete: string[] = [];
    const missingSnapshots: string[] = [];

    for (const cf of fileRows) {
      const safe = safeRelPath(cf.path);
      if (!safe || isBlocked(safe)) continue;

      if (cf.changeType === "added") {
        pathsToDelete.push(safe);
      } else {
        // modified or deleted → restore parent's (or ancestor's) content.
        let sha: string | null = null;
        const parentSnap = await db.blobSnapshot.findUnique({
          where: {
            user_proj_commitId_path: {
              user: DEFAULT_USER,
              proj,
              commitId: parent.id,
              path: safe,
            },
          },
          select: { sha256: true },
        });
        if (parentSnap) {
          sha = parentSnap.sha256;
        } else {
          // Walk ancestors of parent for an older snapshot.
          let cursorHash: string | null = commit.parentHash12;
          for (let i = 0; i < MAX_ANCESTOR_WALK && cursorHash && !sha; i++) {
            const ancestor = await db.commit.findFirst({
              where: {
                user: DEFAULT_USER,
                proj,
                hash12: cursorHash,
                status: "complete",
              },
              select: { id: true, parentHash12: true },
            });
            if (!ancestor) break;
            const snap = await db.blobSnapshot.findUnique({
              where: {
                user_proj_commitId_path: {
                  user: DEFAULT_USER,
                  proj,
                  commitId: ancestor.id,
                  path: safe,
                },
              },
              select: { sha256: true },
            });
            if (snap) sha = snap.sha256;
            cursorHash = ancestor.parentHash12;
          }
        }

        if (sha) {
          const text = await getSnapshotText(DEFAULT_USER, proj, sha);
          if (text !== null) {
            filesToRestore.set(safe, new TextEncoder().encode(text));
          } else {
            missingSnapshots.push(safe);
          }
        } else {
          missingSnapshots.push(safe);
        }
      }
    }

    if (filesToRestore.size === 0 && pathsToDelete.length === 0) {
      return json(
        {
          ok: true,
          empty: true,
          message: "Nothing to revert (commit had no restorable changes)",
        },
        200
      );
    }

    const revertMsg =
      message || `Revert "${commit.message}" (${commit.hash12})`;

    const result = await performCommit({
      user: DEFAULT_USER,
      proj,
      message: revertMsg,
      files: filesToRestore,
      deletes: pathsToDelete,
      mode: "push",
      incremental: true,
    });

    return json(
      {
        ok: true,
        reverted: commit.hash12,
        commit: result.commit,
        restoredFiles: [...filesToRestore.keys()],
        deletedFiles: pathsToDelete,
        missingSnapshots,
      },
      200
    );
  } catch (err) {
    if (err instanceof CommitError) {
      try {
        return json(JSON.parse(err.message), err.status);
      } catch {
        return apiError(err.message, err.status);
      }
    }
    console.error("[revert] error:", err);
    return apiError("Internal server error", 500);
  }
}
