// TinyHub — export project as .zip.
//
// Walks FileBlob rows (the source of truth for the tip state), reads each
// file's bytes via getFile, and zips them up using fflate (pure-JS). A
// manifest.json inside the zip records project, tip commit, exportedAt,
// file list with sizes + sha256, and file count.
//
// Endpoint: GET /api/projects/:proj/export
// Rate limit: cost 3 (heavier read).
// Caps: total uncompressed size at MAX_TOTAL (100 MB); 413 if exceeded.

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { getFile } from "@/lib/storage";
import { applyRateLimit, apiError, handleOptions } from "@/lib/api";
import { zipSync, strToU8 } from "fflate";

export const runtime = "nodejs";

const MAX_TOTAL = 100 * 1024 * 1024; // 100 MB uncompressed cap

interface FileBlobRow {
  path: string;
  sha256: string;
  size: number;
}

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 3);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) return apiError("Invalid project name", 400);

  try {
    const blobs: FileBlobRow[] = await db.fileBlob.findMany({
      where: { user: DEFAULT_USER, proj },
      select: { path: true, sha256: true, size: true },
      orderBy: { path: "asc" },
    });

    if (blobs.length === 0) {
      return apiError("Project has no files to export", 404);
    }

    // Cap total uncompressed size.
    const totalBytes = blobs.reduce((s, b) => s + b.size, 0);
    if (totalBytes > MAX_TOTAL) {
      return apiError(
        `Project too large to export: ${totalBytes} bytes > ${MAX_TOTAL} bytes`,
        413
      );
    }

    // Determine tip commit for the manifest.
    const tip = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, status: "complete" },
      orderBy: { createdAt: "desc" },
      select: { hash12: true },
    });
    const tipHash = tip?.hash12 ?? null;

    // Read each file's bytes (concurrency 8).
    const fileBytesMap = new Map<string, Uint8Array>();
    await Promise.all(
      blobs.map(async (b) => {
        const bytes = await getFile(DEFAULT_USER, proj, b.path);
        if (bytes) fileBytesMap.set(b.path, bytes);
      })
    );

    // Build the zip payload. Skip files whose bytes failed to read (rare race
    // where FileBlob exists but the file was removed from disk).
    const zipData: Record<string, Uint8Array> = {};
    const manifestFiles: Array<{ path: string; size: number; sha256: string }> = [];
    let skipped = 0;
    for (const b of blobs) {
      const bytes = fileBytesMap.get(b.path);
      if (!bytes) {
        skipped++;
        continue;
      }
      zipData[b.path] = bytes;
      manifestFiles.push({ path: b.path, size: b.size, sha256: b.sha256 });
    }

    const manifest = {
      project: proj,
      commit: tipHash,
      exportedAt: Date.now(),
      fileCount: manifestFiles.length,
      skipped,
      files: manifestFiles,
    };
    zipData["manifest.json"] = strToU8(JSON.stringify(manifest, null, 2));

    let zipBytes: Uint8Array;
    try {
      zipBytes = zipSync(zipData, {
        level: 6,
        // Use forward slashes (already the case) — fflate keeps keys as-is.
      });
    } catch (err) {
      console.error("[export] zipSync failed:", err);
      return apiError("Failed to build zip archive", 500);
    }

    const filename = `${proj}-${tipHash ? tipHash.slice(0, 8) : "notip"}.zip`;
    // fflate returns a Uint8Array backed by its own ArrayBuffer — wrap in a
    // fresh Uint8Array view to satisfy Response's BodyInit typing under TS 5.7+.
    const bodyView = new Uint8Array(zipBytes);

    return new Response(bodyView as BodyInit, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${filename}"`,
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
        "Content-Length": String(zipBytes.byteLength),
        "X-TinyHub-Project": proj,
        "X-TinyHub-Tip": tipHash ?? "",
      },
    });
  } catch (err) {
    console.error("[export] error:", err);
    return apiError("Internal server error", 500);
  }
}
