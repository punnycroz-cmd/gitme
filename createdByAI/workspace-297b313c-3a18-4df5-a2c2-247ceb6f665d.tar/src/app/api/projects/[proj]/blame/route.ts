// TinyHub — per-file blame view.
//
// Walks the commit history (newest → oldest) for a single file path and
// attributes each line of the CURRENT tip content to the most recent commit
// whose per-commit BlobSnapshot for that path contained a matching line at the
// same position. This is a position-aware, content-matching blame (not a
// Myers/LCS diff), which is simple and robust for small files.
//
// Endpoint: GET /api/projects/:proj/blame?path=<relpath>
// Rate limit: cost 2 (heavier read).
// Caps: totalLines and lines[] at MAX_LINES (2000); truncated=true when exceeded.

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj, safeRelPath, isBlocked } from "@/lib/security";
import { getFileText, getSnapshotText } from "@/lib/storage";
import { applyRateLimit, json, apiError, handleOptions } from "@/lib/api";

export const runtime = "nodejs";

const MAX_LINES = 2000;

interface CommitRow {
  id: string;
  hash12: string;
  author: string;
  message: string;
  createdAt: bigint;
}

interface CommitFileRow {
  commitId: string;
}

interface SnapshotRow {
  sha256: string;
}

interface BlameCommit {
  hash: string;
  author: string;
  message: string;
  createdAt: number;
  count: number;
}

interface BlameLine {
  line: number;
  content: string;
  commit: {
    hash: string;
    author: string;
    message: string;
    createdAt: number;
  } | null;
}

interface BlameResponse {
  path: string;
  totalLines: number;
  commits: BlameCommit[];
  lines: BlameLine[];
  truncated: boolean;
}

/// Run an async mapper over `items` with at most `limit` concurrent invocations.
async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, idx: number) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let idx = 0;
  async function run(): Promise<void> {
    while (idx < items.length) {
      const i = idx++;
      out[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  return out;
}

/// Strip a single trailing empty string produced by a final newline so line
/// counts read naturally ("a\nb\n".split("\n") → ["a","b",""]).
function splitLines(s: string): string[] {
  const parts = s.length ? s.split("\n") : [];
  if (parts.length > 1 && parts[parts.length - 1] === "") parts.pop();
  return parts;
}

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 2);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) return apiError("Invalid project name", 400);

  const rawPath = req.nextUrl.searchParams.get("path");
  const path = rawPath ? safeRelPath(rawPath) : null;
  if (!path) return apiError("Invalid file path", 400);
  if (isBlocked(path)) return apiError("Path is blocked", 400);

  try {
    // 404 if the file doesn't exist at the current tip.
    const blob = await db.fileBlob.findUnique({
      where: { user_proj_path: { user: DEFAULT_USER, proj, path } },
      select: { sha256: true, size: true, lines: true },
    });
    if (!blob) {
      return apiError("File not found at tip", 404);
    }

    // Read current file content (the lines we will blame).
    const currentText = await getFileText(DEFAULT_USER, proj, path);
    if (currentText === null) {
      return apiError("File content unavailable", 404);
    }
    const currentLines = splitLines(currentText);
    const totalLines = currentLines.length;

    // Find every commit that touched `path` (has a CommitFile row).
    // Then load each commit's metadata + its BlobSnapshot sha256 for this path.
    const commitFileRows: CommitFileRow[] = await db.commitFile.findMany({
      where: { path, commit: { user: DEFAULT_USER, proj, status: "complete" } },
      select: { commitId: true },
      orderBy: { commit: { createdAt: "desc" } },
    });

    // Deduplicate commitIds (a commit may have multiple CommitFile rows for
    // the same path only in pathological cases, but be safe).
    const seenCommitIds = new Set<string>();
    const uniqueCommitIds: string[] = [];
    for (const cf of commitFileRows) {
      if (!seenCommitIds.has(cf.commitId)) {
        seenCommitIds.add(cf.commitId);
        uniqueCommitIds.push(cf.commitId);
      }
    }

    // Load commit metadata (newest first).
    const commits: CommitRow[] = uniqueCommitIds.length
      ? await db.commit.findMany({
          where: { id: { in: uniqueCommitIds }, status: "complete" },
          select: {
            id: true,
            hash12: true,
            author: true,
            message: true,
            createdAt: true,
          },
          orderBy: { createdAt: "desc" },
        })
      : [];

    // For each commit, look up its BlobSnapshot for this path (and read the
    // snapshot text). Build an ordered list of { commit, lines } newest-first.
    const snapshotLinesByCommitId = new Map<string, string[]>();
    await mapLimit(commits, 8, async (c) => {
      const snap: SnapshotRow | null = await db.blobSnapshot.findUnique({
        where: {
          user_proj_commitId_path: {
            user: DEFAULT_USER,
            proj,
            commitId: c.id,
            path,
          },
        },
        select: { sha256: true },
      });
      if (!snap) {
        // Pre-snapshot commit: snapshot text unavailable. Store empty array
        // so we know we visited it but can't match lines against it.
        snapshotLinesByCommitId.set(c.id, []);
        return;
      }
      const text = await getSnapshotText(DEFAULT_USER, proj, snap.sha256);
      snapshotLinesByCommitId.set(c.id, text ? splitLines(text) : []);
    });

    // For each line i of currentLines, find the NEWEST commit whose snapshot
    // has a line at position i that matches currentLines[i].
    // Optimization: iterate commits newest-first; first match wins.
    const lineCommitIdx: number[] = new Array(currentLines.length).fill(-1);
    for (let i = 0; i < currentLines.length; i++) {
      if (i >= MAX_LINES) break;
      const cur = currentLines[i];
      for (let cIdx = 0; cIdx < commits.length; cIdx++) {
        const snapLines = snapshotLinesByCommitId.get(commits[cIdx].id);
        if (!snapLines || snapLines.length === 0) continue;
        // Defensive: snapshot may be shorter than current. Only match when
        // line i exists in the snapshot AND equals currentLines[i].
        if (i < snapLines.length && snapLines[i] === cur) {
          lineCommitIdx[i] = cIdx;
          break;
        }
      }
    }

    // Edge case: lines that didn't match any commit's snapshot (e.g. line
    // existed in the tip but no per-commit snapshot covered it — pre-backfill).
    // Blame them to null OR, if there's at least one commit, fall back to the
    // OLDEST commit that touched the path (so the user sees *some* attribution
    // rather than a hole).
    const fallbackOldestIdx = commits.length > 0 ? commits.length - 1 : -1;
    for (let i = 0; i < lineCommitIdx.length; i++) {
      if (lineCommitIdx[i] === -1 && fallbackOldestIdx >= 0) {
        // Only fall back to the oldest commit if that commit has any snapshot
        // lines for this file (i.e. it touched the file in some form). If the
        // oldest commit is also pre-snapshot (empty snapLines), we leave the
        // line attributed to null.
        const oldestSnap = snapshotLinesByCommitId.get(commits[fallbackOldestIdx].id);
        if (oldestSnap && oldestSnap.length > 0) {
          lineCommitIdx[i] = fallbackOldestIdx;
        }
      }
    }

    // Count lines per commit + build the per-line commit info.
    const countsByCommitIdx = new Map<number, number>();
    const truncated = totalLines > MAX_LINES;
    const outLines: BlameLine[] = [];
    const visibleLineCount = Math.min(totalLines, MAX_LINES);
    for (let i = 0; i < visibleLineCount; i++) {
      const cIdx = lineCommitIdx[i];
      let commitInfo: BlameLine["commit"] = null;
      if (cIdx >= 0) {
        const c = commits[cIdx];
        commitInfo = {
          hash: c.hash12,
          author: c.author,
          message: c.message,
          createdAt: Number(c.createdAt),
        };
        countsByCommitIdx.set(cIdx, (countsByCommitIdx.get(cIdx) ?? 0) + 1);
      }
      outLines.push({
        line: i + 1,
        content: currentLines[i],
        commit: commitInfo,
      });
    }

    const outCommits: BlameCommit[] = commits
      .map((c, idx) => ({
        hash: c.hash12,
        author: c.author,
        message: c.message,
        createdAt: Number(c.createdAt),
        count: countsByCommitIdx.get(idx) ?? 0,
      }))
      .filter((c) => c.count > 0);

    const body: BlameResponse = {
      path,
      totalLines,
      commits: outCommits,
      lines: outLines,
      truncated,
    };
    return json(body);
  } catch (err) {
    console.error("[blame] error:", err);
    return apiError("Internal server error", 500);
  }
}
