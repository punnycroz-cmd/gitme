// TinyHub — repository dump (full / delta / summary; json or html)
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { escapeHtml, safeJsonParse, wantsJson } from "@/lib/helpers";
import { getFileText } from "@/lib/storage";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

const ALWAYS_INCLUDE = new Set([
  "PROJECT_STRUCTURE.md",
  "README.md",
  "package.json",
]);

interface FileRow {
  path: string;
  sha256: string;
  size: number;
}

interface ChangedEntry {
  path: string;
  changeType: string;
}

interface SkippedEntry {
  path: string;
  reason: string;
  size?: number;
}

function underPrefix(path: string, prefix: string): boolean {
  if (!prefix) return true;
  if (path === prefix) return true;
  return path.startsWith(prefix.endsWith("/") ? prefix : prefix + "/");
}

function basename(p: string): string {
  return p.split("/").pop() || p;
}

function isAlwaysInclude(p: string): boolean {
  return ALWAYS_INCLUDE.has(basename(p)) || ALWAYS_INCLUDE.has(p);
}

async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, idx: number) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let idx = 0;
  async function run(): Promise<void> {
    while (idx < items.length) {
      const i = idx++;
      out[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  return out;
}

interface DumpContext {
  proj: string;
  repo: string;
  commit: string | null;
  parent: string | null;
  createdAt: number | null;
  stats: Record<string, number>;
  mode: "full" | "delta" | "summary";
  filesToShow: FileRow[];
  deletedPaths: string[];
  skipped: SkippedEntry[];
}

interface CommitRow {
  hash12: string;
  createdAt: bigint;
  parentHash12: string | null;
}

async function buildContext(
  proj: string,
  mode: "full" | "delta" | "summary",
  sinceRaw: string | null,
  pathFilter: string
): Promise<DumpContext> {
  const repo = `${DEFAULT_USER}/${proj}`;

  // Latest complete commit.
  const latest = await db.commit.findFirst({
    where: { user: DEFAULT_USER, proj, status: "complete" },
    orderBy: { createdAt: "desc" },
    select: {
      hash12: true,
      parentHash12: true,
      createdAt: true,
      statsJson: true,
    },
  });
  const commit = latest?.hash12 ?? null;
  const parent = latest?.parentHash12 ?? null;
  const createdAt = latest ? Number(latest.createdAt) : null;
  const stats = safeJsonParse<Record<string, number>>(latest?.statsJson || "{}", {});

  // Load all FileBlob rows.
  const rows: FileRow[] = await db.fileBlob.findMany({
    where: { user: DEFAULT_USER, proj },
    select: { path: true, sha256: true, size: true },
    orderBy: { path: "asc" },
  });

  const skipped: SkippedEntry[] = [];
  let filesToShow: FileRow[] = [];
  let deletedPaths: string[] = [];

  if (mode === "delta") {
    // Find sinceCommit.
    let sinceCommit: CommitRow | null = null;
    if (sinceRaw === "last") {
      // Use parent of latest.
      if (latest?.parentHash12) {
        sinceCommit = await db.commit.findFirst({
          where: { user: DEFAULT_USER, proj, hash12: latest.parentHash12 },
          select: { hash12: true, createdAt: true, parentHash12: true },
        });
      }
    } else if (sinceRaw) {
      sinceCommit = await db.commit.findFirst({
        where: { user: DEFAULT_USER, proj, hash12: sinceRaw },
        select: { hash12: true, createdAt: true, parentHash12: true },
      });
    }
    if (!sinceCommit) {
      // No baseline: behave like full.
      filesToShow = rows.slice();
    } else {
      // Gather commits createdAt >= sinceCommit.createdAt (including the sinceCommit itself? No — changes AFTER sinceCommit).
      // Use strictly greater to capture commits after the baseline.
      const newerCommits = await db.commit.findMany({
        where: {
          user: DEFAULT_USER,
          proj,
          status: "complete",
          createdAt: { gt: sinceCommit.createdAt },
        },
        orderBy: { createdAt: "asc" },
        select: { id: true },
      });
      const commitIds = newerCommits.map((c) => c.id);
      const changedRows: ChangedEntry[] = commitIds.length
        ? await db.commitFile.findMany({
            where: { commitId: { in: commitIds } },
            select: { path: true, changeType: true },
            distinct: ["path", "changeType"],
          })
        : [];

      const changedPaths = new Set<string>();
      const changedDeleted = new Set<string>();
      for (const c of changedRows) {
        changedPaths.add(c.path);
        if (c.changeType === "deleted") changedDeleted.add(c.path);
      }

      // Modified/added ∪ ALWAYS_INCLUDE (intersected with what exists).
      const blobByPath = new Map(rows.map((r) => [r.path, r] as const));
      const includeSet = new Set<string>();
      for (const p of changedPaths) {
        if (!changedDeleted.has(p)) includeSet.add(p);
      }
      for (const r of rows) {
        if (isAlwaysInclude(r.path)) includeSet.add(r.path);
      }
      filesToShow = [...includeSet]
        .map((p) => blobByPath.get(p))
        .filter((r): r is FileRow => !!r)
        .sort((a, b) => a.path.localeCompare(b.path));

      deletedPaths = [...changedDeleted].sort();
    }
  } else {
    // full / summary — show all blobs.
    filesToShow = rows.slice();
  }

  // Apply path filter.
  if (pathFilter) {
    filesToShow = filesToShow.filter((r) => underPrefix(r.path, pathFilter));
    deletedPaths = deletedPaths.filter((p) => underPrefix(p, pathFilter));
  }

  return {
    proj,
    repo,
    commit,
    parent,
    createdAt,
    stats,
    mode,
    filesToShow,
    deletedPaths,
    skipped,
  };
}

function applyTokenBudget(
  ctx: DumpContext,
  maxTokens: number
): void {
  if (maxTokens <= 0) return;
  const budgetBytes = maxTokens * 4;
  // Sort: ALWAYS_INCLUDE first, then by size ascending.
  const sorted = ctx.filesToShow.slice().sort((a, b) => {
    const ai = isAlwaysInclude(a.path) ? 0 : 1;
    const bi = isAlwaysInclude(b.path) ? 0 : 1;
    if (ai !== bi) return ai - bi;
    return a.size - b.size;
  });
  let used = 0;
  const keep: FileRow[] = [];
  for (const f of sorted) {
    if (f.size > LIMITS.DUMP_MAX_FILE_SIZE && !isAlwaysInclude(f.path)) {
      ctx.skipped.push({
        path: f.path,
        reason: "exceeds DUMP_MAX_FILE_SIZE",
        size: f.size,
      });
      continue;
    }
    if (used + f.size > budgetBytes) {
      ctx.skipped.push({
        path: f.path,
        reason: "token budget exceeded",
        size: f.size,
      });
      continue;
    }
    keep.push(f);
    used += f.size;
  }
  // Restore alphabetical order for output.
  ctx.filesToShow = keep.sort((a, b) => a.path.localeCompare(b.path));
}

function enforceFileCountCap(ctx: DumpContext): void {
  if (ctx.filesToShow.length <= LIMITS.DUMP_MAX_FILES) return;
  const overflow = ctx.filesToShow.slice(LIMITS.DUMP_MAX_FILES);
  for (const f of overflow) {
    ctx.skipped.push({
      path: f.path,
      reason: "exceeds DUMP_MAX_FILES",
      size: f.size,
    });
  }
  ctx.filesToShow = ctx.filesToShow.slice(0, LIMITS.DUMP_MAX_FILES);
}

function enforceTotalCap(ctx: DumpContext): void {
  // Drops oversized / over-total files (mutates ctx).
  const kept: FileRow[] = [];
  let total = 0;
  for (const f of ctx.filesToShow) {
    if (f.size > LIMITS.DUMP_MAX_FILE_SIZE && !isAlwaysInclude(f.path)) {
      ctx.skipped.push({
        path: f.path,
        reason: "exceeds DUMP_MAX_FILE_SIZE",
        size: f.size,
      });
      continue;
    }
    if (total + f.size > LIMITS.DUMP_MAX_TOTAL && !isAlwaysInclude(f.path)) {
      ctx.skipped.push({
        path: f.path,
        reason: "exceeds DUMP_MAX_TOTAL",
        size: f.size,
      });
      continue;
    }
    kept.push(f);
    total += f.size;
  }
  ctx.filesToShow = kept;
}

function etagOf(ctx: DumpContext, suffix: string): string {
  return `"${ctx.repo}-${ctx.commit || "none"}-${ctx.mode}-${suffix}"`;
}

function dumpHeaders(
  etag: string,
  ctx: DumpContext,
  extra: Record<string, string> = {}
): Record<string, string> {
  return {
    ETag: etag,
    "Cache-Control": "no-store, no-cache, must-revalidate",
    "Access-Control-Allow-Origin": "*",
    "X-TinyHub-Commit": ctx.commit || "",
    "X-TinyHub-Parent": ctx.parent || "",
    "X-TinyHub-Created-At": String(ctx.createdAt || ""),
    ...extra,
  };
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return Response.json({ error: "Invalid project name" }, { status: 400 });
  }

  const url = req.nextUrl;
  const modeRaw = (url.searchParams.get("mode") || "full").toLowerCase();
  const mode =
    modeRaw === "delta" || modeRaw === "summary" ? modeRaw : "full";
  const sinceRaw = url.searchParams.get("since");
  const since = sinceRaw === "last" ? "last" : sinceRaw;
  const maxTokensRaw = Number.parseInt(url.searchParams.get("max_tokens") || "0", 10);
  const maxTokens = Number.isFinite(maxTokensRaw) && maxTokensRaw > 0 ? maxTokensRaw : 0;
  const pathFilter = url.searchParams.get("path") || "";
  const wantsHtml =
    (url.searchParams.get("format") || "").toLowerCase() === "html"
      ? true
      : !wantsJson(req, url.searchParams);

  let ctx: DumpContext;
  try {
    ctx = await buildContext(proj, mode as DumpContext["mode"], since, pathFilter);
  } catch (err) {
    console.error("[dump] build error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }

  // ETag check.
  const etag = etagOf(ctx, wantsHtml ? "html" : "json");
  const inm = req.headers.get("If-None-Match");
  if (inm && inm === etag) {
    return new Response(null, { status: 304, headers: { ETag: etag } });
  }

  // Summary mode — no file contents.
  if (mode === "summary") {
    const totalBytes = ctx.filesToShow.reduce((s, f) => s + f.size, 0);
    const body = {
      repo: ctx.repo,
      type: "summary",
      commit: ctx.commit,
      parent: ctx.parent,
      createdAt: ctx.createdAt,
      fileCount: ctx.filesToShow.length,
      totalBytes,
      files: ctx.filesToShow.map((f) => ({
        path: f.path,
        size: f.size,
        sha256: f.sha256,
      })),
      skipped: ctx.skipped,
    };
    return NextResponse.json(body, {
      headers: dumpHeaders(etag, ctx),
    });
  }

  // Apply caps.
  enforceFileCountCap(ctx);
  if (maxTokens > 0) {
    applyTokenBudget(ctx, maxTokens);
  } else {
    enforceTotalCap(ctx);
  }

  // Read file contents (concurrency 8).
  const contents = await mapLimit(ctx.filesToShow, 8, async (f) => {
    const text = await getFileText(DEFAULT_USER, proj, f.path);
    return { path: f.path, size: f.size, sha256: f.sha256, text };
  });

  // Drop any file we couldn't read.
  const present: Array<{ path: string; size: number; sha256: string; text: string }> = [];
  for (const c of contents) {
    if (c.text === null) {
      ctx.skipped.push({ path: c.path, reason: "read failed", size: c.size });
    } else {
      present.push({ ...c, text: c.text });
    }
  }
  ctx.filesToShow = present.map((p) => ({ path: p.path, size: p.size, sha256: p.sha256 }));
  const realTotal = present.reduce((s, p) => s + p.size, 0);

  const typeLabel = mode === "delta" ? "delta" : "dump";

  if (!wantsHtml) {
    const payload: Record<string, string> = {};
    for (const p of present) payload[p.path] = p.text;
    const body = {
      repo: ctx.repo,
      type: typeLabel,
      commit: ctx.commit,
      parent: ctx.parent,
      createdAt: ctx.createdAt,
      stats: ctx.stats,
      fileCount: present.length,
      totalBytes: realTotal,
      files: payload,
      deleted: ctx.deletedPaths,
      skipped: ctx.skipped,
    };
    return NextResponse.json(body, {
      headers: dumpHeaders(etag, ctx),
    });
  }

  // ---- HTML rendering ----
  const html = renderHtml(ctx, present, realTotal, typeLabel);
  return new Response(html, {
    status: 200,
    headers: dumpHeaders(etag, ctx, {
      "Content-Type": "text/html; charset=utf-8",
    }),
  });
}

function renderHtml(
  ctx: DumpContext,
  present: Array<{ path: string; size: number; sha256: string; text: string }>,
  totalBytes: number,
  typeLabel: string
): string {
  const kb = (totalBytes / 1024).toFixed(1);
  const title = `TinyHub — ${ctx.repo} (${typeLabel})`;

  // Build raw text dump.
  const rawLines: string[] = [];
  rawLines.push(`// TinyHub repository ${typeLabel}: ${ctx.repo} @ ${ctx.commit || "none"}`);
  rawLines.push(`// Parent: ${ctx.parent || "none"}`);
  rawLines.push(`// Created at: ${ctx.createdAt ?? "unknown"} (${ctx.createdAt ? new Date(ctx.createdAt).toISOString() : ""})`);
  rawLines.push(`// Files: ${present.length} (${kb} KB)`);
  rawLines.push("");
  for (const p of present) {
    rawLines.push(`// File: ${p.path}`);
    rawLines.push(p.text);
    rawLines.push("");
  }
  const rawText = rawLines.join("\n");

  const fileSections: string[] = [];
  for (const p of present) {
    fileSections.push(
      `<section class="file"><h2>// File: ${escapeHtml(p.path)} <span class="meta">${p.size} bytes · ${escapeHtml(p.sha256.slice(0, 8))}</span></h2><pre>${escapeHtml(p.text)}</pre></section>`
    );
  }
  for (const p of ctx.deletedPaths) {
    fileSections.push(
      `<section class="file deleted"><h2>// File: <span class="del">${escapeHtml(p)}</span> <span class="meta">deleted</span></h2><pre class="del">[deleted]</pre></section>`
    );
  }

  const skippedBlock =
    ctx.skipped.length > 0
      ? `<details class="skipped"><summary>Skipped (${ctx.skipped.length})</summary><ul>${ctx.skipped
          .map(
            (s) =>
              `<li>${escapeHtml(s.path)} — ${escapeHtml(s.reason)}${
                s.size !== undefined ? ` (${s.size} bytes)` : ""
              }</li>`
          )
          .join("")}</ul></details>`
      : "";

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>${escapeHtml(title)}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
  :root { color-scheme: light dark; }
  * { box-sizing: border-box; }
  body {
    font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
    margin: 0;
    padding: 0;
    background: #f6f8fa;
    color: #1f2328;
    line-height: 1.5;
  }
  header {
    background: #1f2328;
    color: #f6f8fa;
    padding: 16px 24px;
    position: sticky;
    top: 0;
    z-index: 10;
    box-shadow: 0 1px 0 rgba(0,0,0,0.2);
  }
  header h1 { margin: 0 0 8px; font-size: 16px; font-weight: 600; }
  .chips { display: flex; gap: 8px; flex-wrap: wrap; align-items: center; }
  .chip {
    display: inline-block;
    padding: 2px 8px;
    background: rgba(255,255,255,0.12);
    border-radius: 999px;
    font-size: 12px;
    color: #f6f8fa;
  }
  .chip.commit { font-family: inherit; }
  button.copy {
    margin-left: auto;
    background: #2da44e;
    color: #fff;
    border: none;
    padding: 6px 12px;
    border-radius: 6px;
    cursor: pointer;
    font: inherit;
    font-size: 12px;
  }
  button.copy:hover { background: #218838; }
  main { padding: 16px 24px 64px; max-width: 1200px; margin: 0 auto; }
  section.file {
    background: #fff;
    border: 1px solid #d0d7de;
    border-radius: 8px;
    margin-bottom: 16px;
    overflow: hidden;
  }
  section.file h2 {
    margin: 0;
    padding: 10px 16px;
    background: #f6f8fa;
    border-bottom: 1px solid #d0d7de;
    font-size: 13px;
    font-weight: 600;
    color: #24292f;
  }
  section.file h2 .meta { font-weight: 400; color: #57606a; margin-left: 8px; }
  section.file pre {
    margin: 0;
    padding: 12px 16px;
    overflow-x: auto;
    font-size: 13px;
    white-space: pre-wrap;
    word-break: break-word;
    color: #1f2328;
  }
  section.file.deleted h2 { color: #82071e; background: #ffebe9; }
  section.file.deleted pre.del { color: #82071e; font-style: italic; }
  .skipped { margin: 16px 0; font-size: 12px; }
  .skipped summary { cursor: pointer; color: #57606a; }
  .skipped ul { margin: 8px 0 0 16px; padding: 0; color: #57606a; }
  footer { padding: 16px 24px; color: #57606a; font-size: 12px; text-align: center; }
  textarea.hidden { position: absolute; left: -9999px; top: -9999px; }
  @media (prefers-color-scheme: dark) {
    body { background: #0d1117; color: #c9d1d9; }
    section.file { background: #161b22; border-color: #30363d; }
    section.file h2 { background: #0d1117; border-color: #30363d; color: #c9d1d9; }
    section.file h2 .meta { color: #8b949e; }
    section.file pre { color: #c9d1d9; }
    section.file.deleted h2 { background: #4a2024; color: #ff7b72; }
    section.file.deleted pre.del { color: #ff7b72; }
    .skipped summary, .skipped ul, footer { color: #8b949e; }
  }
</style>
</head>
<body>
<header>
  <h1>${escapeHtml(title)}</h1>
  <div class="chips">
    <span class="chip">${present.length} files</span>
    <span class="chip">${kb} KB</span>
    <span class="chip commit">commit ${escapeHtml(ctx.commit || "none")}</span>
    ${ctx.parent ? `<span class="chip">parent ${escapeHtml(ctx.parent)}</span>` : ""}
    <button class="copy" type="button" onclick="copyAll()">Copy All</button>
  </div>
</header>
<main>
  ${skippedBlock}
  ${fileSections.join("\n")}
</main>
<footer>TinyHub · ${escapeHtml(ctx.repo)} · ${escapeHtml(typeLabel)}</footer>
<textarea class="hidden" id="rawDump">${escapeHtml(rawText)}</textarea>
<script>
  function copyAll() {
    var ta = document.getElementById('rawDump');
    ta.focus();
    ta.select();
    try {
      document.execCommand('copy');
      var btn = document.querySelector('button.copy');
      if (btn) { var t = btn.textContent; btn.textContent = 'Copied!'; setTimeout(function(){ btn.textContent = t; }, 1500); }
    } catch (e) {
      alert('Copy failed: ' + e.message);
    }
  }
</script>
</body>
</html>`;
}
