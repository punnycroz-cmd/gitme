// TinyHub — per-commit diff (file-level changes + before/after content)
//
// v2: Uses per-commit BlobSnapshot rows to provide REAL before/after content.
//   - For a modified file in commit C:
//       before = snapshot of that path at C's most recent ancestor that touched it
//       after  = snapshot at commit C
//   - For an added file: before = null, after = snapshot at C
//   - For a deleted file: before = snapshot at C's most recent ancestor that touched it,
//     after = null
// Snapshot blobs are content-addressed (storage/snapshots/<user>/<proj>/<sha256>), deduped.
// Falls back to the v1 behavior (current file content, before=null) only when a snapshot
// is missing (e.g. commits created before snapshots were introduced).
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { safeJsonParse } from "@/lib/helpers";
import { getFileText, getSnapshotText } from "@/lib/storage";
import { applyRateLimit, json, apiError } from "@/lib/api";

export const runtime = "nodejs";

const HASH_RE = /^[a-f0-9]{12}$/;
const MAX_ANCESTOR_WALK = 200; // safety cap when walking parent chain

interface CommitFileRow {
  path: string;
  changeType: string;
}

interface DiffFile {
  path: string;
  changeType: "added" | "modified" | "deleted";
  before: string | null;
  after: string | null;
  size: number;
}

interface CommitStats {
  added?: number;
  modified?: number;
  deleted?: number;
  unchanged?: number;
}

/// Run an async mapper over `items` with at most `limit` concurrent invocations.
async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, idx: number) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let idx = 0;
  async function run(): Promise<void> {
    while (idx < items.length) {
      const i = idx++;
      out[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  return out;
}

/// Find the most recent ancestor of `commitId` (exclusive) that has a BlobSnapshot
/// for `path`. Walks the parent chain via parentHash12. Returns the snapshot's
/// sha256 (to read content) or null if none found.
async function findAncestorSnapshotSha(
  user: string,
  proj: string,
  commitId: string,
  parentHash12: string | null,
  path: string
): Promise<string | null> {
  let cursorHash: string | null = parentHash12;
  let steps = 0;
  while (cursorHash && steps < MAX_ANCESTOR_WALK) {
    steps++;
    // Find the ancestor commit row.
    const ancestor = await db.commit.findFirst({
      where: { user, proj, hash12: cursorHash, status: "complete" },
      select: { id: true, parentHash12: true },
    });
    if (!ancestor) break;
    // Does this ancestor have a snapshot for `path`?
    const snap = await db.blobSnapshot.findUnique({
      where: {
        user_proj_commitId_path: { user, proj, commitId: ancestor.id, path },
      },
      select: { sha256: true },
    });
    if (snap) return snap.sha256;
    cursorHash = ancestor.parentHash12;
  }
  return null;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string; hash: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj, hash: rawHash } = await params;
  const proj = safeProj(rawProj);
  if (!proj) return apiError("Invalid project name", 400);

  const hash = (rawHash || "").trim().toLowerCase();
  if (!HASH_RE.test(hash)) {
    return apiError("Invalid commit hash (expected 12 hex chars)", 400);
  }

  try {
    const commit = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, hash12: hash, status: "complete" },
      select: {
        id: true,
        hash12: true,
        parentHash12: true,
        author: true,
        message: true,
        statsJson: true,
        createdAt: true,
      },
    });
    if (!commit) {
      return apiError("Commit not found", 404);
    }

    const fileRows: CommitFileRow[] = await db.commitFile.findMany({
      where: { commitId: commit.id },
      select: { path: true, changeType: true },
      orderBy: { path: "asc" },
    });

    // Determine if this commit is the current tip.
    const tip = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, status: "complete" },
      orderBy: { createdAt: "desc" },
      select: { hash12: true },
    });
    const isTip = !!tip && tip.hash12 === commit.hash12;

    const files: DiffFile[] = await mapLimit(fileRows, 8, async (cf) => {
      const ct = cf.changeType;

      // Look up the snapshot AT this commit (the "after" state for added/modified).
      const afterSnap = await db.blobSnapshot.findUnique({
        where: {
          user_proj_commitId_path: {
            user: DEFAULT_USER,
            proj,
            commitId: commit.id,
            path: cf.path,
          },
        },
        select: { sha256: true, size: true },
      });

      if (ct === "deleted") {
        // before = ancestor snapshot of this path; after = null.
        const beforeSha = await findAncestorSnapshotSha(
          DEFAULT_USER,
          proj,
          commit.id,
          commit.parentHash12,
          cf.path
        );
        const beforeText = beforeSha
          ? await getSnapshotText(DEFAULT_USER, proj, beforeSha)
          : null;
        return {
          path: cf.path,
          changeType: "deleted",
          before: beforeText,
          after: null,
          size: beforeText ? new TextEncoder().encode(beforeText).byteLength : 0,
        };
      }

      // added | modified
      const changeType = ct === "added" ? "added" : "modified";

      // Read "after" content: prefer the snapshot blob; fall back to current file.
      let afterText: string | null = null;
      if (afterSnap) {
        afterText = await getSnapshotText(DEFAULT_USER, proj, afterSnap.sha256);
      }
      if (afterText === null) {
        // Snapshot missing (pre-v2 commit) — fall back to current file content.
        afterText = await getFileText(DEFAULT_USER, proj, cf.path);
      }

      // Read "before" content for modified files: walk ancestors.
      let beforeText: string | null = null;
      if (ct === "modified") {
        const beforeSha = await findAncestorSnapshotSha(
          DEFAULT_USER,
          proj,
          commit.id,
          commit.parentHash12,
          cf.path
        );
        if (beforeSha) {
          beforeText = await getSnapshotText(DEFAULT_USER, proj, beforeSha);
        }
        // If beforeSha is null, the file existed (it was "modified") but no
        // snapshot was stored (pre-v2). Fall back to null before — the viewer
        // will show the v1 note for this file.
      }

      return {
        path: cf.path,
        changeType,
        before: beforeText,
        after: afterText,
        size: afterText ? new TextEncoder().encode(afterText).byteLength : 0,
      };
    });

    const stats = safeJsonParse<CommitStats>(commit.statsJson, {});

    // v2 note: only mention the historical limitation if ANY modified file
    // has a null before (i.e. snapshots were missing for it).
    const hasMissingBefore = files.some(
      (f) => f.changeType === "modified" && f.before === null
    );
    const note = hasMissingBefore
      ? isTip
        ? "Showing exact file content at this commit. Some modified files lack historical before-content (created before snapshot support was added)."
        : "This is not the tip commit. Some modified files lack historical before-content (created before snapshot support was added); their 'after' reflects the snapshot at this commit."
      : "Showing exact before/after content for every changed file (per-commit snapshots).";

    return json({
      hash: commit.hash12,
      parentHash: commit.parentHash12,
      author: commit.author,
      message: commit.message,
      createdAt: Number(commit.createdAt),
      stats: {
        added: stats.added ?? 0,
        modified: stats.modified ?? 0,
        deleted: stats.deleted ?? 0,
        unchanged: stats.unchanged ?? 0,
      },
      files,
      isTip,
      note,
    });
  } catch (err) {
    console.error("[commit-diff] error:", err);
    return apiError("Internal server error", 500);
  }
}
