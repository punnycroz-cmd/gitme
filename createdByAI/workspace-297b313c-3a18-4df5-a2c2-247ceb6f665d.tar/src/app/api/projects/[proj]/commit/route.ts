// TinyHub — JSON commit endpoint (text-only file payloads)
import { NextRequest } from "next/server";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj, safeRelPath, isBlocked } from "@/lib/security";
import { safeJsonParse } from "@/lib/helpers";
import {
  performCommit,
  CommitError,
  type CommitResult,
} from "@/lib/commit";
import {
  applyRateLimit,
  requireWriteAuth,
  handleOptions,
  apiError,
  json,
} from "@/lib/api";

export const runtime = "nodejs";

function handleCommitError(err: unknown): Response {
  if (err instanceof CommitError) {
    const msg = err.message;
    if (msg.startsWith("{")) {
      try {
        const body = JSON.parse(msg) as Record<string, unknown>;
        return json(body, err.status);
      } catch {
        /* fall through */
      }
    }
    return apiError(msg, err.status);
  }
  console.error("[commit-engine] error:", err);
  return apiError("Internal server error", 500);
}

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 5);
  if (rl) return rl;

  const auth = requireWriteAuth(req);
  if (auth) return auth;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return apiError("Invalid project name", 400);
  }

  // Read raw body with size cap.
  let raw: string;
  try {
    raw = await req.text();
  } catch {
    return apiError("Invalid request body", 400);
  }
  if (raw.length > LIMITS.MAX_COMMIT_PAYLOAD) {
    return apiError(
      `Request body too large (max ${LIMITS.MAX_COMMIT_PAYLOAD} bytes)`,
      413
    );
  }

  const body = safeJsonParse<Record<string, unknown> | null>(raw, null);
  if (!body || typeof body !== "object") {
    return apiError("Invalid JSON body", 400);
  }

  const message =
    typeof body.message === "string" ? body.message : "";
  const baseTip =
    typeof body.baseTip === "string" ? body.baseTip : undefined;
  // Optional author override (from Settings). Falls back to "TinyHub".
  const author =
    typeof body.author === "string" && body.author.trim()
      ? body.author.trim().slice(0, 100)
      : "TinyHub";

  // files: Record<path, text>
  const filesRaw = body.files;
  const files = new Map<string, Uint8Array>();
  if (filesRaw !== undefined && filesRaw !== null) {
    if (typeof filesRaw !== "object" || Array.isArray(filesRaw)) {
      return apiError("Invalid 'files' (expected object of path -> text)", 400);
    }
    const entries = Object.entries(filesRaw as Record<string, unknown>);
    const encoder = new TextEncoder();
    for (const [path, content] of entries) {
      if (typeof content !== "string") {
        return apiError(`File content for '${path}' must be a string`, 400);
      }
      const safe = safeRelPath(path);
      if (!safe || isBlocked(safe)) continue; // skip blocked
      files.set(safe, encoder.encode(content));
    }
  }

  // deletes: string[]
  const deletes: string[] = [];
  if (Array.isArray(body.deletes)) {
    for (const d of body.deletes) {
      if (typeof d !== "string") continue;
      const safe = safeRelPath(d);
      if (!safe || isBlocked(safe)) continue;
      deletes.push(safe);
    }
  }

  if (files.size === 0 && deletes.length === 0) {
    return apiError("No files or deletes provided", 400);
  }

  let result: CommitResult;
  try {
    result = await performCommit({
      user: DEFAULT_USER,
      proj,
      message,
      files,
      deletes,
      mode: "push",
      incremental: true,
      baseTip,
      author,
    });
  } catch (err) {
    return handleCommitError(err);
  }

  return json(result, 200);
}
