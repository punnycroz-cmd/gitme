// TinyHub — fetch raw file content
import { NextRequest } from "next/server";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj, safeRelPath, isBlocked } from "@/lib/security";
import { guessContentType } from "@/lib/helpers";
import { getFile } from "@/lib/storage";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return Response.json({ error: "Invalid project name" }, { status: 400 });
  }

  const url = req.nextUrl;
  const rawPath = url.searchParams.get("path") || "";
  const relPath = safeRelPath(rawPath);
  if (!relPath || isBlocked(relPath)) {
    return Response.json({ error: "Invalid or blocked file path" }, { status: 400 });
  }

  try {
    const bytes = await getFile(DEFAULT_USER, proj, relPath);
    if (!bytes) {
      return Response.json({ error: "File not found" }, { status: 404 });
    }
    return new Response(bytes as BodyInit, {
      status: 200,
      headers: {
        "Content-Type": guessContentType(relPath),
        "Cache-Control": "public, max-age=3600",
        "Access-Control-Allow-Origin": "*",
        "Content-Length": String(bytes.byteLength),
      },
    });
  } catch (err) {
    console.error("[file] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
