// TinyHub — commit comparison (diff between any two commits).
//
// Returns the SAME response shape as /api/projects/:proj/commit/:hash so the
// frontend DiffViewer / CompareDiffViewer can render it unchanged:
//   { hash, parentHash, author, message, createdAt, stats, files, isTip, note }
//
// Endpoint: GET /api/projects/:proj/compare?from=<hash12>&to=<hash12>
// Rate limit: cost 2 (heavier read — walks snapshots + ancestors).
//
// Algorithm (pragmatic v1 — documented in note):
//   The "tree at commit X" is approximated by the BlobSnapshot rows AT commit X.
//   We then diff the two approximated trees:
//     1. Gather BlobSnapshot rows at `from` commit (path → sha256) and at `to`.
//     2. For paths in BOTH:
//          - same sha256 → unchanged (skipped from output)
//          - different sha256 → modified (before = snapshot@from, after = snapshot@to)
//     3. For paths only in `to` → added (before=null, after=snapshot@to; fallback to getFileText)
//     4. For paths only in `from`:
//          - if FileBlob row exists at the current tip → unchanged (the file still
//            exists; `to` simply didn't re-snapshot it because it didn't touch it).
//          - else → deleted (before=snapshot@from, after=null)
//   This means: comparing two commits where NEITHER touched a given file will
//   correctly report it as unchanged (no false diff). Added/modified/deleted will
//   only appear for files actually touched between the two commits.
//
// Edge cases:
//   - from === to → returns an empty-changes response with note "Same commit …".
//   - from is newer than to → swapped; we still return `from` = older, `to` = newer
//     (the response fields `hash`/`parentHash` always reflect newer/older).
//   - either commit missing or not status:complete → 404.

import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { getFileText, getSnapshotText } from "@/lib/storage";
import { applyRateLimit, json, apiError, handleOptions } from "@/lib/api";

export const runtime = "nodejs";

const HASH_RE = /^[a-f0-9]{12}$/;

interface SnapshotRow {
  path: string;
  sha256: string;
  size: number;
}

interface CommitRow {
  id: string;
  hash12: string;
  parentHash12: string | null;
  author: string;
  message: string;
  createdAt: bigint;
}

interface DiffFile {
  path: string;
  changeType: "added" | "modified" | "deleted";
  before: string | null;
  after: string | null;
  size: number;
}

interface CompareResponse {
  hash: string;
  parentHash: string | null;
  author: string;
  message: string;
  createdAt: number;
  stats: { added: number; modified: number; deleted: number; unchanged: number };
  files: DiffFile[];
  isTip: boolean;
  note: string;
}

/// Run an async mapper over `items` with at most `limit` concurrent invocations.
async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T, idx: number) => Promise<R>
): Promise<R[]> {
  const out: R[] = new Array(items.length);
  let idx = 0;
  async function run(): Promise<void> {
    while (idx < items.length) {
      const i = idx++;
      out[i] = await fn(items[i], i);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, run));
  return out;
}

function byteLength(s: string): number {
  return new TextEncoder().encode(s).byteLength;
}

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 2);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) return apiError("Invalid project name", 400);

  const fromRaw = (req.nextUrl.searchParams.get("from") || "").trim().toLowerCase();
  const toRaw = (req.nextUrl.searchParams.get("to") || "").trim().toLowerCase();
  if (!HASH_RE.test(fromRaw) || !HASH_RE.test(toRaw)) {
    return apiError(
      "Invalid commit hash(es) — expected 12 hex chars for both `from` and `to`",
      400
    );
  }

  try {
    // Look up both commits.
    const [fromCommit0, toCommit0] = await Promise.all([
      db.commit.findFirst({
        where: { user: DEFAULT_USER, proj, hash12: fromRaw, status: "complete" },
        select: {
          id: true,
          hash12: true,
          parentHash12: true,
          author: true,
          message: true,
          createdAt: true,
        },
      }),
      db.commit.findFirst({
        where: { user: DEFAULT_USER, proj, hash12: toRaw, status: "complete" },
        select: {
          id: true,
          hash12: true,
          parentHash12: true,
          author: true,
          message: true,
          createdAt: true,
        },
      }),
    ]);

    if (!fromCommit0) return apiError("`from` commit not found", 404);
    if (!toCommit0) return apiError("`to` commit not found", 404);

    // Determine which is older. `from` should be the older one; swap if needed.
    let fromCommit: CommitRow = fromCommit0 as CommitRow;
    let toCommit: CommitRow = toCommit0 as CommitRow;
    let swapped = false;
    if (fromCommit0.createdAt > toCommit0.createdAt) {
      fromCommit = toCommit0 as CommitRow;
      toCommit = fromCommit0 as CommitRow;
      swapped = true;
    }

    const fromHash = fromCommit.hash12;
    const toHash = toCommit.hash12;
    const fromShort = fromHash.slice(0, 8);
    const toShort = toHash.slice(0, 8);

    // Same commit selected → empty diff.
    if (fromHash === toHash) {
      const body: CompareResponse = {
        hash: toHash,
        parentHash: fromHash,
        author: toCommit.author,
        message: `Compare ${toShort} → ${toShort}`,
        createdAt: Number(toCommit.createdAt),
        stats: { added: 0, modified: 0, deleted: 0, unchanged: 0 },
        files: [],
        isTip: false,
        note: "Same commit selected for both sides — no changes to compare.",
      };
      return json(body);
    }

    // Gather BlobSnapshot rows for both commits.
    const [fromSnaps, toSnaps] = await Promise.all([
      db.blobSnapshot.findMany({
        where: { user: DEFAULT_USER, proj, commitId: fromCommit.id },
        select: { path: true, sha256: true, size: true },
      }),
      db.blobSnapshot.findMany({
        where: { user: DEFAULT_USER, proj, commitId: toCommit.id },
        select: { path: true, sha256: true, size: true },
      }),
    ]);

    const fromMap = new Map<string, SnapshotRow>();
    for (const s of fromSnaps) fromMap.set(s.path, s);
    const toMap = new Map<string, SnapshotRow>();
    for (const s of toSnaps) toMap.set(s.path, s);

    // Collect all distinct paths.
    const allPaths = new Set<string>([...fromMap.keys(), ...toMap.keys()]);

    // For paths only in `from`, we need to know whether they still exist at the
    // current tip (FileBlob) — this distinguishes "deleted" from "unchanged
    // (just not re-snapshotted by `to`)".
    const fromOnlyPaths: string[] = [];
    for (const p of allPaths) {
      if (fromMap.has(p) && !toMap.has(p)) fromOnlyPaths.push(p);
    }
    let tipBlobPaths: Set<string> | null = null;
    if (fromOnlyPaths.length > 0) {
      const tipBlobs = await db.fileBlob.findMany({
        where: { user: DEFAULT_USER, proj, path: { in: fromOnlyPaths } },
        select: { path: true },
      });
      tipBlobPaths = new Set(tipBlobs.map((b) => b.path));
    }

    // Determine current tip (for the `isTip` field).
    const tip = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, status: "complete" },
      orderBy: { createdAt: "desc" },
      select: { hash12: true },
    });
    const isTip = !!tip && tip.hash12 === toHash;

    // Build the list of changed files (skip unchanged).
    const changedPaths: {
      path: string;
      changeType: "added" | "modified" | "deleted";
    }[] = [];
    for (const p of allPaths) {
      const f = fromMap.get(p);
      const t = toMap.get(p);
      if (f && t) {
        if (f.sha256 === t.sha256) continue; // unchanged
        changedPaths.push({ path: p, changeType: "modified" });
      } else if (!f && t) {
        changedPaths.push({ path: p, changeType: "added" });
      } else if (f && !t) {
        // `from` had it, `to` doesn't have a snapshot. Decide:
        //   - if the file still exists at the tip → treat as unchanged (skip).
        //   - else → deleted.
        if (tipBlobPaths && tipBlobPaths.has(p)) continue; // unchanged
        changedPaths.push({ path: p, changeType: "deleted" });
      }
    }
    changedPaths.sort((a, b) => a.path.localeCompare(b.path));

    // Fetch before/after content for each changed file (concurrency cap 8).
    const files: DiffFile[] = await mapLimit(changedPaths, 8, async (c) => {
      const f = fromMap.get(c.path);
      const t = toMap.get(c.path);

      if (c.changeType === "added") {
        // before = null, after = snapshot@to (fallback: current file content).
        let afterText: string | null = null;
        if (t) {
          afterText = await getSnapshotText(DEFAULT_USER, proj, t.sha256);
        }
        if (afterText === null) {
          // Snapshot missing (pre-v2 or externally removed) — fall back to tip.
          afterText = await getFileText(DEFAULT_USER, proj, c.path);
        }
        return {
          path: c.path,
          changeType: "added",
          before: null,
          after: afterText,
          size: afterText ? byteLength(afterText) : 0,
        };
      }

      if (c.changeType === "deleted") {
        // before = snapshot@from, after = null.
        let beforeText: string | null = null;
        if (f) {
          beforeText = await getSnapshotText(DEFAULT_USER, proj, f.sha256);
        }
        return {
          path: c.path,
          changeType: "deleted",
          before: beforeText,
          after: null,
          size: beforeText ? byteLength(beforeText) : 0,
        };
      }

      // modified
      let beforeText: string | null = null;
      let afterText: string | null = null;
      if (f) {
        beforeText = await getSnapshotText(DEFAULT_USER, proj, f.sha256);
      }
      if (t) {
        afterText = await getSnapshotText(DEFAULT_USER, proj, t.sha256);
      }
      if (afterText === null) {
        // Snapshot missing at `to` — fall back to tip content.
        afterText = await getFileText(DEFAULT_USER, proj, c.path);
      }
      return {
        path: c.path,
        changeType: "modified",
        before: beforeText,
        after: afterText,
        size: afterText ? byteLength(afterText) : 0,
      };
    });

    // Count stats (unchanged here = files that existed in both with same sha +
    // files in `from` only that still exist at tip).
    let unchangedCount = 0;
    for (const p of allPaths) {
      const f = fromMap.get(p);
      const t = toMap.get(p);
      if (f && t) {
        if (f.sha256 === t.sha256) unchangedCount++;
      } else if (f && !t) {
        if (tipBlobPaths && tipBlobPaths.has(p)) unchangedCount++;
      }
    }

    const added = files.filter((f) => f.changeType === "added").length;
    const modified = files.filter((f) => f.changeType === "modified").length;
    const deleted = files.filter((f) => f.changeType === "deleted").length;

    const noteParts: string[] = [];
    if (swapped) {
      noteParts.push(
        `Comparing commit ${fromShort} (older — originally \`to\`) → commit ${toShort} (newer — originally \`from\`).`
      );
    } else {
      noteParts.push(
        `Comparing commit ${fromShort} (older) → commit ${toShort} (newer).`
      );
    }
    noteParts.push(
      "Diff is computed from per-commit BlobSnapshot rows: added = path only at \`to\`; deleted = path only at \`from\` and not present at the tip; modified = path at both with different content."
    );

    const body: CompareResponse = {
      hash: toHash,
      parentHash: fromHash,
      author: toCommit.author,
      message: `Compare ${fromShort} → ${toShort}`,
      createdAt: Number(toCommit.createdAt),
      stats: { added, modified, deleted, unchanged: unchangedCount },
      files,
      isTip,
      note: noteParts.join(" "),
    };
    return json(body);
  } catch (err) {
    console.error("[compare] error:", err);
    return apiError("Internal server error", 500);
  }
}
