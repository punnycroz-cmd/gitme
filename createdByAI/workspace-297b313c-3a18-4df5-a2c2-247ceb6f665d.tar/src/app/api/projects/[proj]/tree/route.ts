// TinyHub — file tree / flat / meta listing for a project
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { buildStructuredTree, type TreeNode } from "@/lib/helpers";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

interface FileMetaRow {
  path: string;
  sha256: string;
  size: number;
  lines: number;
}

/// Filter paths under a prefix: either exact match or `<prefix>/...`
function underPrefix(path: string, prefix: string): boolean {
  if (!prefix) return true;
  if (path === prefix) return true;
  return path.startsWith(prefix.endsWith("/") ? prefix : prefix + "/");
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return Response.json({ error: "Invalid project name" }, { status: 400 });
  }

  const url = req.nextUrl;
  const meta = url.searchParams.get("meta") === "1";
  const flat = url.searchParams.get("flat") === "1";
  const pathFilter = url.searchParams.get("path") || "";
  const pageRaw = Number.parseInt(url.searchParams.get("page") || "1", 10);
  const pageSizeRaw = Number.parseInt(
    url.searchParams.get("pageSize") || String(LIMITS.TREE_DEFAULT_PAGE_SIZE),
    10
  );
  const page = Number.isFinite(pageRaw) && pageRaw > 0 ? pageRaw : 1;
  const pageSize =
    Number.isFinite(pageSizeRaw) && pageSizeRaw > 0
      ? Math.min(pageSizeRaw, 10000)
      : LIMITS.TREE_DEFAULT_PAGE_SIZE;

  try {
    // Load FileBlob rows — source of truth for tip file state.
    const rows: FileMetaRow[] = await db.fileBlob.findMany({
      where: { user: DEFAULT_USER, proj },
      select: { path: true, sha256: true, size: true, lines: true },
      orderBy: { path: "asc" },
    });

    // Latest complete commit (for commit hash + createdAt).
    const latest = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, status: "complete" },
      orderBy: { createdAt: "desc" },
      select: { hash12: true, createdAt: true },
    });
    const commit = latest?.hash12 ?? null;
    const createdAt = latest ? Number(latest.createdAt) : null;

    // Apply path filter
    const filtered = pathFilter
      ? rows.filter((r) => underPrefix(r.path, pathFilter))
      : rows;

    // Sort
    filtered.sort((a, b) => a.path.localeCompare(b.path));

    const total = filtered.length;
    const startIdx = (page - 1) * pageSize;
    const paged = filtered.slice(startIdx, startIdx + pageSize);
    const paths = paged.map((r) => r.path);

    // ETag based on commit + page + pageSize + filter
    const etag = `"${proj}-${commit || "none"}-${page}-${pageSize}-${pathFilter}-${
      meta ? "m" : flat ? "f" : "t"
    }"`;
    const inm = req.headers.get("If-None-Match");
    if (inm && inm === etag) {
      return new Response(null, { status: 304, headers: { ETag: etag } });
    }

    const base: Record<string, unknown> = {
      repo: `${DEFAULT_USER}/${proj}`,
      project: proj,
      commit,
      createdAt,
      page,
      pageSize,
      total,
    };

    if (flat) {
      return Response.json(
        { ...base, files: paths, count: paths.length },
        {
          headers: {
            ETag: etag,
            "Cache-Control": "no-cache",
            "Access-Control-Allow-Origin": "*",
          },
        }
      );
    }

    if (meta) {
      const sizeMap: Record<string, number | null> = {};
      for (const r of paged) sizeMap[r.path] = r.size;
      const { tree } = buildStructuredTree(paths, sizeMap);
      return Response.json(
        {
          ...base,
          files: paged.map((r) => ({
            path: r.path,
            size: r.size,
            sha256: r.sha256,
            lines: r.lines,
          })),
          tree: tree as TreeNode[],
          count: paged.length,
        },
        {
          headers: {
            ETag: etag,
            "Cache-Control": "no-cache",
            "Access-Control-Allow-Origin": "*",
          },
        }
      );
    }

    // Default: structured tree
    const sizeMap: Record<string, number | null> = {};
    for (const r of paged) sizeMap[r.path] = r.size;
    const { tree } = buildStructuredTree(paths, sizeMap);
    return Response.json(
      { ...base, files: paths, tree: tree as TreeNode[], count: paths.length },
      {
        headers: {
          ETag: etag,
          "Cache-Control": "no-cache",
          "Access-Control-Allow-Origin": "*",
        },
      }
    );
  } catch (err) {
    console.error("[tree] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
