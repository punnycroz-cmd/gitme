// TinyHub — code search across project files
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { getFileText } from "@/lib/storage";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

interface SearchMatch {
  path: string;
  line: number;
  snippet: string;
}

function underPrefix(path: string, prefix: string): boolean {
  if (!prefix) return true;
  if (path === prefix) return true;
  return path.startsWith(prefix.endsWith("/") ? prefix : prefix + "/");
}

async function readLinesConcurrently(
  tasks: { path: string; size: number }[],
  worker: (path: string) => Promise<string | null>,
  concurrency = 8
): Promise<Array<{ path: string; text: string | null }>> {
  const out: Array<{ path: string; text: string | null }> = new Array(tasks.length);
  let idx = 0;
  async function run(): Promise<void> {
    while (idx < tasks.length) {
      const i = idx++;
      const text = await worker(tasks[i].path);
      out[i] = { path: tasks[i].path, text };
    }
  }
  await Promise.all(Array.from({ length: Math.min(concurrency, tasks.length) }, run));
  return out;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return Response.json({ error: "Invalid project name" }, { status: 400 });
  }

  const url = req.nextUrl;
  const q = (url.searchParams.get("q") || "").toString();
  if (!q) {
    return Response.json({ error: "Missing query parameter 'q'" }, { status: 400 });
  }

  const useRegex = url.searchParams.get("regex") === "1";
  const pathFilter = url.searchParams.get("path") || "";
  const maxRaw = Number.parseInt(url.searchParams.get("max") || "50", 10);
  const max = Number.isFinite(maxRaw)
    ? Math.min(Math.max(maxRaw, 1), 200)
    : LIMITS.SEARCH_MAX_MATCHES;

  let matcher: (line: string) => boolean;
  if (useRegex) {
    if (q.length > 50) {
      return Response.json(
        { error: "Regex query too long (max 50 chars)" },
        { status: 400 }
      );
    }
    let re: RegExp;
    try {
      re = new RegExp(q, "i");
    } catch {
      return Response.json({ error: "Invalid regular expression" }, { status: 400 });
    }
    matcher = (line: string) => re.test(line);
  } else {
    const needle = q.toLowerCase();
    matcher = (line: string) => line.toLowerCase().includes(needle);
  }

  try {
    // Load file blobs (path, size) — source of truth.
    const rows = await db.fileBlob.findMany({
      where: { user: DEFAULT_USER, proj },
      select: { path: true, size: true },
      orderBy: { path: "asc" },
    });

    // Filter by size + path prefix; cap to SEARCH_MAX_FILES.
    const candidates = rows
      .filter((r) => r.size <= LIMITS.SEARCH_MAX_FILE_SIZE)
      .filter((r) => underPrefix(r.path, pathFilter))
      .slice(0, LIMITS.SEARCH_MAX_FILES)
      .map((r) => ({ path: r.path, size: r.size }));

    const texts = await readLinesConcurrently(
      candidates,
      (p) => getFileText(DEFAULT_USER, proj, p),
      8
    );

    const matches: SearchMatch[] = [];
    let truncated = false;

    for (const { path, text } of texts) {
      if (text === null) continue;
      const lines = text.split("\n");
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        if (matcher(line)) {
          const snippet = line.length > 200 ? line.slice(0, 200) : line;
          matches.push({ path, line: i + 1, snippet });
          if (matches.length >= max) {
            truncated = true;
            break;
          }
        }
      }
      if (truncated) break;
    }

    return Response.json({
      query: q,
      regex: useRegex,
      matches,
      count: matches.length,
      truncated,
    });
  } catch (err) {
    console.error("[search] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
