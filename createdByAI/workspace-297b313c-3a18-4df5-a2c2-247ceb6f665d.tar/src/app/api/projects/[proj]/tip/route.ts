// TinyHub — current tip for a project
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return Response.json({ error: "Invalid project name" }, { status: 400 });
  }

  try {
    const latest = await db.commit.findFirst({
      where: { user: DEFAULT_USER, proj, status: "complete" },
      orderBy: { createdAt: "desc" },
      select: { hash12: true, createdAt: true },
    });
    return Response.json({
      commit: latest?.hash12 ?? null,
      created_at: latest ? Number(latest.createdAt) : null,
    });
  } catch (err) {
    console.error("[tip] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
