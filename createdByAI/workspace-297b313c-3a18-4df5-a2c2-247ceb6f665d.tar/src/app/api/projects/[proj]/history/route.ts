// TinyHub — commit history (paginated)
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { safeJsonParse } from "@/lib/helpers";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

interface CommitStats {
  added?: number;
  modified?: number;
  deleted?: number;
  unchanged?: number;
}

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return Response.json({ error: "Invalid project name" }, { status: 400 });
  }

  const url = req.nextUrl;
  const pageRaw = Number.parseInt(url.searchParams.get("page") || "1", 10);
  const pageSizeRaw = Number.parseInt(
    url.searchParams.get("pageSize") || String(LIMITS.HISTORY_DEFAULT_PAGE_SIZE),
    10
  );
  const page = Number.isFinite(pageRaw) && pageRaw > 0 ? pageRaw : 1;
  const pageSize = Number.isFinite(pageSizeRaw)
    ? Math.min(Math.max(pageSizeRaw, 1), 200)
    : LIMITS.HISTORY_DEFAULT_PAGE_SIZE;

  // Optional date filter: ?date=YYYY-MM-DD filters commits to that UTC day.
  const dateParam = url.searchParams.get("date");
  let dateFilter: { gte?: bigint; lt?: bigint } | undefined;
  if (dateParam && /^\d{4}-\d{2}-\d{2}$/.test(dateParam)) {
    const dayStart = new Date(`${dateParam}T00:00:00Z`).getTime();
    const dayEnd = new Date(`${dateParam}T23:59:59.999Z`).getTime();
    dateFilter = { gte: BigInt(dayStart), lt: BigInt(dayEnd + 1) };
  }

  try {
    const where = {
      user: DEFAULT_USER,
      proj,
      status: "complete" as const,
      ...(dateFilter ? { createdAt: dateFilter } : {}),
    };
    const [rows, total] = await Promise.all([
      db.commit.findMany({
        where,
        orderBy: { createdAt: "desc" },
        skip: (page - 1) * pageSize,
        take: pageSize,
        select: {
          id: true,
          hash12: true,
          parentHash12: true,
          author: true,
          message: true,
          statsJson: true,
          createdAt: true,
        },
      }),
      db.commit.count({ where }),
    ]);

    return Response.json({
      page,
      pageSize,
      total,
      date: dateParam || null,
      commits: rows.map((r) => ({
        id: r.id,
        hash: r.hash12,
        parent: r.parentHash12,
        author: r.author,
        message: r.message,
        stats: safeJsonParse<CommitStats>(r.statsJson, {}),
        date: new Date(Number(r.createdAt)).toISOString(),
      })),
    });
  } catch (err) {
    console.error("[history] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
