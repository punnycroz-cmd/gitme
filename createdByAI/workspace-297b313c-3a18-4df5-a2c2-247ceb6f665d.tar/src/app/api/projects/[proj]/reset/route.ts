// TinyHub — reset (delete) an entire project
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { safeProj } from "@/lib/security";
import { walkProjectFiles, deleteFiles, deleteAllSnapshots } from "@/lib/storage";
import {
  applyRateLimit,
  requireWriteAuth,
  handleOptions,
  apiError,
} from "@/lib/api";

export const runtime = "nodejs";

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ proj: string }> }
) {
  // Preflight
  if (req.method === "OPTIONS") {
    const rl = applyRateLimit(req, 1);
    if (rl) return rl;
    return handleOptions();
  }

  const rl = applyRateLimit(req, 5);
  if (rl) return rl;

  const auth = requireWriteAuth(req);
  if (auth) return auth;

  const { proj: rawProj } = await params;
  const proj = safeProj(rawProj);
  if (!proj) {
    return apiError("Invalid project name", 400);
  }

  try {
    // 1. Delete FileBlob rows (current tip state).
    await db.fileBlob.deleteMany({ where: { user: DEFAULT_USER, proj } });
    // 2. Delete BlobSnapshot rows (per-commit history) — GC.
    const snapRows = await db.blobSnapshot.deleteMany({
      where: { user: DEFAULT_USER, proj },
    });
    // 3. Delete commits (cascades to CommitFile).
    await db.commit.deleteMany({ where: { user: DEFAULT_USER, proj } });
    // 4. Delete the project row.
    await db.project.deleteMany({ where: { user: DEFAULT_USER, proj } });

    // 5. Delete filesystem files (project blobs).
    const diskFiles = await walkProjectFiles(DEFAULT_USER, proj);
    if (diskFiles.length > 0) {
      await deleteFiles(
        DEFAULT_USER,
        proj,
        diskFiles.map((f) => f.path)
      );
    }

    // 6. Delete all content-addressed snapshot blobs on disk (GC).
    const snapBlobsRemoved = await deleteAllSnapshots(DEFAULT_USER, proj);

    return Response.json({
      ok: true,
      message: "Project reset completed",
      project: proj,
      deletedFiles: diskFiles.length,
      deletedSnapshots: snapRows.count,
      deletedSnapshotBlobs: snapBlobsRemoved,
    });
  } catch (err) {
    console.error("[reset] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
