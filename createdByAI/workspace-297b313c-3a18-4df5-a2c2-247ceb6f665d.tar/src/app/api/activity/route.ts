// TinyHub — activity sparkline data (commits over the last 30 days for default user).
// Returns per-day commit counts + project coverage for the dashboard sparkline.
//
// v1 aggregates in JS by reading complete commits for DEFAULT_USER. This is fine for
// small projects; for scale, replace with a SQL GROUP BY date(createdAt/1000, 'unixepoch')
// query against the Commit table.
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { applyRateLimit, handleOptions } from "@/lib/api";

export const runtime = "nodejs";

export async function OPTIONS(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;
  return handleOptions();
}

export interface ActivityDay {
  date: string; // YYYY-MM-DD (UTC)
  count: number;
  projects: number;
}

export interface ActivityResponse {
  days: ActivityDay[];
  total: number;
  maxDay: number;
  maxDate: string | null;
}

const DAY_MS = 24 * 60 * 60 * 1000;

function utcDayKey(ms: number): string {
  // YYYY-MM-DD in UTC, matching `new Date(ms).toISOString().slice(0,10)`.
  return new Date(ms).toISOString().slice(0, 10);
}

export async function GET(req: NextRequest) {
  const rl = applyRateLimit(req, 1);
  if (rl) return rl;

  try {
    // For v1 we load all complete commits for the default user. No `take` cap — projects
    // are small. Add a defensive cap of 50k to avoid pathological cases.
    const rows = await db.commit.findMany({
      where: { user: DEFAULT_USER, status: "complete" },
      select: { createdAt: true, proj: true },
      take: 50_000,
    });

    // Build a 30-day window ending today (UTC). Oldest → newest.
    const nowMs = Date.now();
    const todayKey = utcDayKey(nowMs);
    const todayStart = Date.UTC(
      Number(todayKey.slice(0, 4)),
      Number(todayKey.slice(5, 7)) - 1,
      Number(todayKey.slice(8, 10))
    );

    const days: ActivityDay[] = [];
    const dayMap = new Map<string, { count: number; projects: Set<string> }>();
    for (let i = 29; i >= 0; i--) {
      const dayMs = todayStart - i * DAY_MS;
      const key = utcDayKey(dayMs);
      days.push({ date: key, count: 0, projects: 0 });
      dayMap.set(key, { count: 0, projects: new Set<string>() });
    }

    let total = 0;
    let maxDay = 0;
    let maxDate: string | null = null;

    for (const r of rows) {
      const ts = Number(r.createdAt);
      if (!Number.isFinite(ts)) continue;
      const key = utcDayKey(ts);
      const bucket = dayMap.get(key);
      if (!bucket) continue; // outside the 30-day window
      bucket.count += 1;
      bucket.projects.add(r.proj);
      total += 1;
    }

    // Materialize projects count + track max day.
    for (const d of days) {
      const bucket = dayMap.get(d.date);
      if (bucket) {
        d.count = bucket.count;
        d.projects = bucket.projects.size;
      }
      if (d.count > maxDay) {
        maxDay = d.count;
        maxDate = d.date;
      }
    }

    const body: ActivityResponse = { days, total, maxDay, maxDate };
    return Response.json(body, {
      headers: {
        "Cache-Control": "no-store, no-cache, must-revalidate, max-age=0",
      },
    });
  } catch (err) {
    console.error("[activity] error:", err);
    return Response.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
