// TinyHub — yearly contribution heatmap data (GitHub-style).
// Returns commit counts per day for the last 53 weeks, grouped into weeks
// (columns) × days (rows). Used by the Dashboard heatmap widget.
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER } from "@/lib/config";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

const DAY_MS = 24 * 60 * 60 * 1000;

function utcDayKey(ms: number): string {
  return new Date(ms).toISOString().slice(0, 10);
}

export async function GET(req: NextRequest) {
  const rl = applyRateLimit(req, 2);
  if (rl) return rl;

  try {
    const commits = await db.commit.findMany({
      where: { user: DEFAULT_USER, status: "complete" },
      select: { createdAt: true },
    });

    const now = Date.now();
    // Align the grid so TODAY is the last cell. Today's UTC midnight is the
    // reference; we walk back to the Sunday of the week containing (today - 52 weeks).
    const todayKey = utcDayKey(now);
    const todayMs = Date.parse(todayKey + "T00:00:00Z"); // UTC midnight today
    const todayDow = new Date(todayMs).getUTCDay(); // 0=Sun
    // The Sunday that starts today's week:
    const thisWeekSunday = todayMs - todayDow * DAY_MS;
    // Start = 52 weeks before thisWeekSunday.
    const start = thisWeekSunday - 52 * 7 * DAY_MS;

    const counts = new Map<string, number>();
    for (const c of commits) {
      const ms = Number(c.createdAt);
      if (ms < start) continue;
      const key = utcDayKey(ms);
      counts.set(key, (counts.get(key) || 0) + 1);
    }

    // Build 53 weeks (364 days) starting from `start`. The last cell is
    // start + 52*7*DAY_MS + 6*DAY_MS = thisWeekSunday + 6*DAY_MS = this Saturday.
    // Days after today are marked future (count=0).
    const todayEndMs = todayMs + DAY_MS - 1;
    const weeks: Array<
      Array<{ date: string; count: number; future: boolean }>
    > = [];
    let maxCount = 0;
    for (let w = 0; w < 53; w++) {
      const week: Array<{ date: string; count: number; future: boolean }> = [];
      for (let d = 0; d < 7; d++) {
        const dayMs = start + (w * 7 + d) * DAY_MS;
        const date = utcDayKey(dayMs);
        const future = dayMs > todayEndMs;
        const count = future ? 0 : counts.get(date) || 0;
        if (count > maxCount) maxCount = count;
        week.push({ date, count, future });
      }
      weeks.push(week);
    }

    const total = commits.filter((c) => Number(c.createdAt) >= start).length;

    return Response.json({
      weeks,
      total,
      maxCount,
      weeksSpan: 53,
    });
  } catch (err) {
    console.error("[activity-heatmap] error:", err);
    return Response.json({ error: "Internal server error" }, { status: 500 });
  }
}
