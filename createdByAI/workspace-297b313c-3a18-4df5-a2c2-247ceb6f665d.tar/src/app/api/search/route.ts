// TinyHub — global code search across ALL projects for the default user.
// Returns matches grouped by project. Reuses the same matching logic as the
// per-project search endpoint but iterates every project's FileBlob rows.
import { NextRequest } from "next/server";
import { db } from "@/lib/db";
import { DEFAULT_USER, LIMITS } from "@/lib/config";
import { isBlocked, safeRelPath } from "@/lib/security";
import { getFileText } from "@/lib/storage";
import { applyRateLimit } from "@/lib/api";

export const runtime = "nodejs";

interface GlobalMatch {
  project: string;
  path: string;
  line: number;
  snippet: string;
}

interface ProjectResult {
  project: string;
  count: number;
  matches: GlobalMatch[];
}

export async function GET(req: NextRequest) {
  const rl = applyRateLimit(req, 3); // global search is heavier
  if (rl) return rl;

  const url = req.nextUrl;
  const query = url.searchParams.get("q") || "";
  if (!query) {
    return Response.json({ error: "Missing ?q= parameter" }, { status: 400 });
  }

  const useRegex = url.searchParams.get("regex") === "1";
  const maxMatches = Math.min(
    Math.max(parseInt(url.searchParams.get("max") || "50"), 1),
    200
  );

  let matcher: RegExp | null = null;
  if (useRegex) {
    if (query.length > 50) {
      return Response.json(
        { error: "Regex pattern too long (max 50 chars)" },
        { status: 400 }
      );
    }
    try {
      matcher = new RegExp(query, "i");
    } catch (e) {
      return Response.json(
        { error: "Invalid regex: " + (e instanceof Error ? e.message : "parse error") },
        { status: 400 }
      );
    }
  }
  const queryLower = query.toLowerCase();

  // Load all projects for the default user.
  const projects = await db.project.findMany({
    where: { user: DEFAULT_USER },
    select: { proj: true },
  });

  const results: ProjectResult[] = [];
  let totalMatches = 0;
  let truncated = false;

  for (const { proj } of projects) {
    if (totalMatches >= maxMatches) {
      truncated = true;
      break;
    }
    // Load this project's FileBlob rows (path, size).
    const blobs = await db.fileBlob.findMany({
      where: { user: DEFAULT_USER, proj },
      select: { path: true, size: true },
    });
    // Filter to searchable files.
    const searchable = blobs.filter(
      (b) => !isBlocked(b.path) && b.size <= LIMITS.SEARCH_MAX_FILE_SIZE
    );
    // Cap files per project to bound work.
    const MAX_FILES_PER_PROJECT = 50;
    const filesToSearch = searchable.slice(0, MAX_FILES_PER_PROJECT);

    const projMatches: GlobalMatch[] = [];
    for (const b of filesToSearch) {
      if (totalMatches + projMatches.length >= maxMatches) {
        truncated = true;
        break;
      }
      try {
        const text = await getFileText(DEFAULT_USER, proj, b.path);
        if (text === null) continue;
        const lines = text.split("\n");
        for (let j = 0; j < lines.length; j++) {
          if (totalMatches + projMatches.length >= maxMatches) {
            truncated = true;
            break;
          }
          const line = lines[j];
          const isMatch = matcher
            ? matcher.test(line)
            : line.toLowerCase().includes(queryLower);
          if (isMatch) {
            projMatches.push({
              project: proj,
              path: b.path,
              line: j + 1,
              snippet: line.length > 200 ? line.substring(0, 200) + "…" : line,
            });
          }
        }
      } catch {
        /* ignore file read errors */
      }
    }
    if (projMatches.length > 0) {
      results.push({
        project: proj,
        count: projMatches.length,
        matches: projMatches,
      });
      totalMatches += projMatches.length;
    }
  }

  return Response.json({
    query,
    regex: useRegex,
    matches: results.flatMap((r) => r.matches),
    projects: results,
    count: totalMatches,
    projectsSearched: projects.length,
    filesCapPerProject: 50,
    truncated,
  });
}
