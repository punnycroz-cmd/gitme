// TinyHub — public config (limits, user) for clients
import { NextResponse } from "next/server";
import { DEFAULT_USER, LIMITS } from "@/lib/config";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({
    apiBase: "",
    user: DEFAULT_USER,
    limits: {
      MAX_FILE_SIZE: LIMITS.MAX_FILE_SIZE,
      DUMP_MAX_FILES: LIMITS.DUMP_MAX_FILES,
      DUMP_MAX_TOTAL: LIMITS.DUMP_MAX_TOTAL,
      DUMP_MAX_FILE_SIZE: LIMITS.DUMP_MAX_FILE_SIZE,
    },
  });
}
