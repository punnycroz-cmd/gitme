// TinyHub — health check (no rate limit)
import { NextResponse } from "next/server";
import { DEFAULT_USER } from "@/lib/config";

export const runtime = "nodejs";

export async function GET() {
  return NextResponse.json({
    status: "ok",
    user: DEFAULT_USER,
    timestamp: Date.now(),
  });
}
